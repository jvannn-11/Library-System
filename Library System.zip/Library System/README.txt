INTELLIJ SETUP
1. File > Open > select this folder (the one with pom.xml). Choose "Open as Project", trust it.
2. Wait for Maven to download the SQLite driver (bottom-right progress bar). If asked, click "Load Maven Changes".
3. Open src/main/java/App.java and click the green arrow next to main.
4. Login: librarian / library123

No Maven? Put sqlite-jdbc.jar anywhere, right-click it > Add as Library, then run App.
