import javax.swing.*;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Member home: their numbers, trending books, and the books they have out. */
public class MemberHomePanel extends JPanel implements Refreshable {
    private final LibraryService service;
    private final Account account;
    private final JLabel subtitle = Theme.subtitle(" ");
    private final JLabel out = Theme.big(Theme.INK);
    private final JLabel dueSoon = Theme.big(Theme.WARN_FG);
    private final JLabel late = Theme.big(Theme.ERR_FG);
    private final JLabel fines = Theme.big(Theme.INK);
    private final JPanel yourBooks = Theme.column();
    private final TrendingStrip trending;

    public MemberHomePanel(LibraryService service, Account account, MemberFrame frame) {
        this.service = service;
        this.account = account;
        this.trending = new TrendingStrip(service, b -> BookDialog.show(this, service, b, account, this::refresh));
        setLayout(new BorderLayout());
        setOpaque(false);

        JPanel page = Theme.page();
        page.add(Theme.pageHeader("Home", subtitle, null), BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(0, 24));
        body.setOpaque(false);
        JPanel stats = new JPanel(new GridLayout(1, 4, 16, 0));
        stats.setOpaque(false);
        stats.add(Theme.statCard("Books out", out));
        stats.add(Theme.statCard("Due within 3 days", dueSoon));
        stats.add(Theme.statCard("Overdue", late));
        stats.add(Theme.statCard("Fines owed", fines));
        body.add(stats, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 24));
        center.setOpaque(false);
        center.add(trending, BorderLayout.NORTH);

        Theme.RoundedPanel mine = Theme.card(18, 24);
        mine.setLayout(new BorderLayout(0, 12));
        mine.add(yourBooks, BorderLayout.CENTER);
        JButton browse = Theme.outlineButton("Browse books");
        browse.addActionListener(e -> frame.show("browse"));
        JPanel btn = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        btn.setOpaque(false);
        btn.add(browse);
        mine.add(btn, BorderLayout.SOUTH);
        center.add(mine, BorderLayout.CENTER);
        body.add(center, BorderLayout.CENTER);

        page.add(Ui.scroll(body), BorderLayout.CENTER);
        add(page);
    }

    private JPanel row(String title, String status, int kind) {
        JPanel r = new JPanel(new BorderLayout());
        r.setOpaque(false);
        r.setBorder(BorderFactory.createCompoundBorder(
                new MatteBorder(0, 0, 1, 0, Theme.ROW_LINE), BorderFactory.createEmptyBorder(11, 0, 11, 0)));
        r.add(Theme.label(title, 14, Font.BOLD, Theme.INK), BorderLayout.WEST);
        r.add(Theme.label(status, 13, Font.BOLD, kind == Theme.NEUTRAL ? Theme.MUTED : Theme.fg(kind)), BorderLayout.EAST);
        r.setAlignmentX(Component.LEFT_ALIGNMENT);
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        return r;
    }

    @Override
    public void refresh() {
        LocalDate today = LocalDate.now();
        try {
            Member me = service.findMember(Member.code(account.getMemberId()));
            if (me == null) {
                Theme.error(this, "Your member record could not be found.");
                return;
            }
            subtitle.setText("Welcome back, " + me.getName() + " \u00B7 "
                    + today.format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")));
            out.setText(me.getActiveLoans() + " of " + Loan.MAX_LOANS);
            late.setText(String.valueOf(me.getOverdueLoans()));
            fines.setText(Theme.money(me.getFineOwed()));

            yourBooks.removeAll();
            yourBooks.add(Theme.cardTitle("Your books"));
            yourBooks.add(Box.createVerticalStrut(6));
            int soon = 0, shown = 0;
            List<Loan> mine = service.loansForMember(me.getMemberId());
            for (Loan l : mine) {
                if (l.isReturned()) continue;
                int kind = Ui.dueKind(l, today);
                if (kind == Theme.WARN) soon++;
                if (shown < 4) {
                    yourBooks.add(row(l.getBookTitle(), Ui.dueText(l, today), kind));
                    shown++;
                }
            }
            dueSoon.setText(String.valueOf(soon));
            if (shown == 0) {
                yourBooks.add(Theme.label("You have no books out. Browse the catalog to borrow one!",
                        14, Font.PLAIN, Theme.MUTED));
            }
            trending.refresh();
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
        revalidate();
        repaint();
    }
}