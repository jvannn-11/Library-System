import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/** Global modern touches: slim scrollbars, dialog colours for light/dark mode, and the gradient page banner. */
public final class Modern {
    private Modern() { }

    /** Call after Theme.setDark(...) and before any window is created. */
    public static void install() {
        Color ink = Theme.INK;
        UIManager.put("ScrollBarUI", "Modern$SlimScrollBarUI");
        UIManager.put("Panel.background", Theme.BG);
        UIManager.put("OptionPane.background", Theme.BG);
        UIManager.put("OptionPane.messageForeground", ink);
        UIManager.put("OptionPane.messageFont", Theme.font(Font.PLAIN, 14));
        UIManager.put("OptionPane.buttonFont", Theme.font(Font.BOLD, 13));
        UIManager.put("Label.foreground", ink);
        UIManager.put("Label.font", Theme.font(Font.PLAIN, 14));
        for (String k : new String[] { "TextField", "PasswordField", "FormattedTextField", "ComboBox", "Spinner", "List" }) {
            UIManager.put(k + ".background", Theme.FIELD_BG);
            UIManager.put(k + ".foreground", ink);
        }
        UIManager.put("TextField.caretForeground", ink);
        UIManager.put("PasswordField.caretForeground", ink);
        UIManager.put("FormattedTextField.caretForeground", ink);
        UIManager.put("ComboBox.selectionBackground", Theme.SELECT);
        UIManager.put("ComboBox.selectionForeground", ink);
        UIManager.put("List.selectionBackground", Theme.SELECT);
        UIManager.put("List.selectionForeground", ink);
        UIManager.put("ComboBox.font", Theme.font(Font.PLAIN, 14));
        UIManager.put("Spinner.font", Theme.font(Font.PLAIN, 14));
        UIManager.put("ToolTip.background", Theme.SURFACE);
        UIManager.put("ToolTip.foreground", ink);
        UIManager.put("ToolTip.font", Theme.font(Font.PLAIN, 12));
    }

    public static class SlimScrollBarUI extends BasicScrollBarUI {
        public static ComponentUI createUI(JComponent c) { return new SlimScrollBarUI(); }

        @Override protected void installDefaults() {
            super.installDefaults();
            scrollbar.setOpaque(false);
        }
        @Override protected void configureScrollBarColors() {
            thumbColor = Theme.isDark() ? new Color(0x3C5257) : new Color(0xC3CFCB);
            trackColor = new Color(0, 0, 0, 0);
        }
        @Override protected JButton createDecreaseButton(int o) { return none(); }
        @Override protected JButton createIncreaseButton(int o) { return none(); }

        private static JButton none() {
            JButton b = new JButton();
            Dimension zero = new Dimension(0, 0);
            b.setPreferredSize(zero);
            b.setMinimumSize(zero);
            b.setMaximumSize(zero);
            return b;
        }

        @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }

        @Override protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty() || !scrollbar.isEnabled()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color hot = Theme.isDark() ? new Color(0x57737A) : new Color(0x9FB3AD);
            g2.setColor(isThumbRollover() ? hot : thumbColor);
            if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
                g2.fillRoundRect(r.x + 3, r.y + 2, r.width - 6, r.height - 4, 8, 8);
            } else {
                g2.fillRoundRect(r.x + 2, r.y + 3, r.width - 4, r.height - 6, 8, 8);
            }
            g2.dispose();
        }

        @Override public Dimension getPreferredSize(JComponent c) {
            return scrollbar.getOrientation() == JScrollBar.VERTICAL ? new Dimension(12, 48) : new Dimension(48, 12);
        }
    }

    /** Gradient page banner with the page title and subtitle in white. */
    public static class Hero extends JPanel {
        public Hero(String title, JLabel subtitle) {
            setOpaque(false);
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setBorder(new EmptyBorder(22, 28, 22, 28));
            JLabel t = Theme.label(title, 28, Font.BOLD, Color.WHITE);
            t.setAlignmentX(Component.LEFT_ALIGNMENT);
            subtitle.setForeground(new Color(0xCCFBF1));
            subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
            add(t);
            add(Box.createVerticalStrut(4));
            add(subtitle);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            g2.setClip(new RoundRectangle2D.Float(0, 0, w, h, 22, 22));
            g2.setPaint(new GradientPaint(0, 0, new Color(0x0B5F58), w, h, new Color(0x14B8A6)));
            g2.fillRect(0, 0, w, h);
            g2.setColor(new Color(255, 255, 255, 28));
            g2.fillOval(w - 220, -90, 300, 300);
            g2.setColor(new Color(255, 255, 255, 18));
            g2.fillOval(w - 380, h - 60, 200, 200);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}