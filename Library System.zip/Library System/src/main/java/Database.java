import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Opens the SQLite database and creates every table automatically.
 * The file always lives in the same place: <home folder>/LibrarySystem/library.db
 */
public final class Database {
    private static final File DIR = new File(System.getProperty("user.home"), "LibrarySystem");
    private static final File FILE = new File(DIR, "library.db");
    private static final String URL = "jdbc:sqlite:" + FILE.getAbsolutePath();

    public static final String DEFAULT_USER = "librarian";
    public static final String DEFAULT_PASSWORD = "library123";

    private Database() { }

    public static String getPath() { return FILE.getAbsolutePath(); }

    public static Connection connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite driver not found. Put sqlite-jdbc.jar in the project's +libs folder.");
        }
        Connection c = DriverManager.getConnection(URL);
        try (Statement s = c.createStatement()) {
            s.execute("PRAGMA foreign_keys = ON");
        }
        return c;
    }

    private static void addColumnIfMissing(Statement s, String table, String column, String definition) throws SQLException {
        boolean found = false;
        try (ResultSet rs = s.executeQuery("PRAGMA table_info(" + table + ")")) {
            while (rs.next()) {
                if (column.equalsIgnoreCase(rs.getString("name"))) found = true;
            }
        }
        if (!found) s.execute("ALTER TABLE " + table + " ADD COLUMN " + definition);
    }

    /** Safe to call every time the program starts. Also upgrades an older database file. */
    public static void initialize() throws SQLException {
        DIR.mkdirs();
        try (Connection c = connect(); Statement s = c.createStatement()) {
            s.execute("CREATE TABLE IF NOT EXISTS books ("
                    + "book_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "title TEXT NOT NULL, author TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '',"
                    + "total_copies INTEGER NOT NULL CHECK (total_copies > 0),"
                    + "active INTEGER NOT NULL DEFAULT 1,"
                    + "image_path TEXT NOT NULL DEFAULT '')");
            s.execute("CREATE TABLE IF NOT EXISTS members ("
                    + "member_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "name TEXT NOT NULL, address TEXT NOT NULL DEFAULT '', contact TEXT NOT NULL DEFAULT '',"
                    + "active INTEGER NOT NULL DEFAULT 1)");
            s.execute("CREATE TABLE IF NOT EXISTS loans ("
                    + "loan_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "book_id INTEGER NOT NULL REFERENCES books(book_id),"
                    + "member_id INTEGER NOT NULL REFERENCES members(member_id),"
                    + "borrow_date TEXT NOT NULL, due_date TEXT NOT NULL, return_date TEXT,"
                    + "fine_amount REAL NOT NULL DEFAULT 0, fine_paid INTEGER NOT NULL DEFAULT 0)");
            s.execute("CREATE TABLE IF NOT EXISTS users ("
                    + "username TEXT PRIMARY KEY, salt TEXT NOT NULL, password_hash TEXT NOT NULL,"
                    + "role TEXT NOT NULL DEFAULT 'admin', member_id INTEGER)");

            // upgrade databases made before covers and member logins existed
            addColumnIfMissing(s, "books", "image_path", "image_path TEXT NOT NULL DEFAULT ''");
            addColumnIfMissing(s, "users", "role", "role TEXT NOT NULL DEFAULT 'admin'");
            addColumnIfMissing(s, "users", "member_id", "member_id INTEGER");

            boolean hasAdmin;
            try (ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM users WHERE role = 'admin'")) {
                rs.next();
                hasAdmin = rs.getInt(1) > 0;
            }
            if (!hasAdmin) {
                String salt = PasswordUtil.newSalt();
                String hash = PasswordUtil.hash(DEFAULT_PASSWORD, salt);
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO users (username, salt, password_hash, role) VALUES (?,?,?, 'admin')")) {
                    ps.setString(1, DEFAULT_USER);
                    ps.setString(2, salt);
                    ps.setString(3, hash);
                    ps.executeUpdate();
                }
            }
        }
    }
}