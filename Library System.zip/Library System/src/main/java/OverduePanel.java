import javax.swing.*;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Overdue & Fines: late books, unpaid fines, and the library rules. */
public class OverduePanel extends JPanel implements Refreshable {
    private final LibraryService service;
    private final JLabel overdue = Theme.big(Theme.ERR_FG);
    private final JLabel fines = Theme.big(Theme.INK);
    private final JLabel longest = Theme.big(Theme.INK);
    private final DefaultTableModel model = Theme.model("Member", "Book", "Due", "Days late", "Fine", "");
    private final JTable table = Theme.table(model);
    private List<Loan> rows = new ArrayList<Loan>();

    public OverduePanel(LibraryService service) {
        this.service = service;
        setLayout(new BorderLayout());
        setOpaque(false);

        JPanel page = Theme.page();
        page.add(Theme.pageHeader("Overdue & Fines",
                Theme.subtitle("Books past their due date and the fines owed."), null), BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(0, 24));
        body.setOpaque(false);

        JPanel stats = new JPanel(new GridLayout(1, 3, 16, 0));
        stats.setOpaque(false);
        stats.add(Theme.statCard("Overdue loans", overdue));
        stats.add(Theme.statCard("Fines owed", fines));
        stats.add(Theme.statCard("Longest overdue", longest));
        body.add(stats, BorderLayout.NORTH);

        JPanel lower = new JPanel(new BorderLayout(24, 0));
        lower.setOpaque(false);
        Theme.setWidths(table, 200, 200, 80, 110, 100, 200);
        new Theme.ButtonColumn(table, 5, row -> act(row));
        lower.add(Theme.tableCard(table), BorderLayout.CENTER);

        Theme.RoundedPanel rules = Theme.card(18, 24);
        rules.setLayout(new BoxLayout(rules, BoxLayout.Y_AXIS));
        rules.add(Theme.cardTitle("Library rules"));
        rules.add(Box.createVerticalStrut(8));
        rules.add(rule("Loan period", Loan.LOAN_DAYS + " days"));
        rules.add(rule("Fine per day late", Theme.money(Loan.FINE_PER_DAY)));
        rules.add(rule("Books per member", String.valueOf(Loan.MAX_LOANS)));
        rules.add(Box.createVerticalStrut(10));
        JLabel note = new JLabel("<html><body style='width:225px'>Fines are counted from the due date to the return date. A member with an "
                + "overdue book or unpaid fine cannot borrow.</body></html>");
        note.setFont(Theme.font(Font.PLAIN, 13));
        note.setForeground(Theme.MUTED);
        note.setAlignmentX(Component.LEFT_ALIGNMENT);
        rules.add(note);
        rules.setPreferredSize(new Dimension(320, rules.getPreferredSize().height));
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(rules, BorderLayout.NORTH);
        lower.add(top, BorderLayout.EAST);

        body.add(lower, BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        add(page);
    }

    private JPanel rule(String name, String value) {
        JPanel r = new JPanel(new BorderLayout());
        r.setOpaque(false);
        r.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(0, 0, 1, 0, Theme.ROW_LINE), BorderFactory.createEmptyBorder(10, 0, 10, 0)));
        r.add(Theme.label(name, 14, Font.PLAIN, Theme.INK), BorderLayout.WEST);
        r.add(Theme.label(value, 14, Font.BOLD, Theme.INK), BorderLayout.EAST);
        r.setAlignmentX(Component.LEFT_ALIGNMENT);
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        return r;
    }

    /** A late book still out gets "Record return"; a returned book with an unpaid fine gets "Mark fine paid". */
    private void act(int row) {
        if (row < 0 || row >= rows.size()) return;
        Loan l = rows.get(row);
        try {
            if (l.isReturned()) {
                if (Theme.confirm(this, "Mark the fine of " + Theme.money(l.fine(LocalDate.now()))
                        + " from " + l.getMemberName() + " as paid?")) {
                    service.markFinePaid(l.getLoanId());
                }
            } else if (Theme.confirm(this, "Record the return of \"" + l.getBookTitle() + "\" today?")) {
                service.returnLoan(l.getLoanId());
            }
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
        refresh();
    }

    @Override
    public void refresh() {
        LocalDate today = LocalDate.now();
        try {
            LibraryService.Stats s = service.getStats();
            overdue.setText(String.valueOf(s.overdueLoans));
            fines.setText(Theme.money(s.finesOwed));
            longest.setText(s.longestOverdue + (s.longestOverdue == 1 ? " day" : " days"));
            rows = service.overdueRows();
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
            return;
        }
        model.setRowCount(0);
        for (Loan l : rows) {
            model.addRow(new Object[] {
                "<html><b>" + l.getMemberName() + "</b><br><font color='#4B5563' size='2'>"
                    + Member.code(l.getMemberId()) + "</font></html>",
                l.getBookTitle(),
                l.getDueDate().format(DateTimeFormatter.ofPattern("MMM d")),
                new Theme.Chip(String.valueOf(l.daysLate(today)), Theme.ERR),
                Theme.money(l.fine(today)),
                l.isReturned() ? "Mark fine paid" : "Record return"
            });
        }
    }
}
