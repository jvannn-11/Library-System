import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/** Catalog: cover grid with search, add (with cover image) and click-to-borrow. */
public class CatalogPanel extends JPanel implements Refreshable {
    private final LibraryService service;
    private final BookBrowser browser;

    public CatalogPanel(LibraryService service) {
        this.service = service;
        this.browser = new BookBrowser(service,
                b -> BookDialog.show(this, service, b, Account.admin(), this::refresh));
        setLayout(new BorderLayout());
        setOpaque(false);

        JPanel page = Theme.page();
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        JButton add = Theme.button("+ Add book");
        right.add(add);
        page.add(Theme.pageHeader("Catalog",
                        Theme.subtitle("Click a book to borrow it for a member, change its cover or remove it."), right),
                BorderLayout.NORTH);
        page.add(browser, BorderLayout.CENTER);
        add(page);

        add.addActionListener(e -> showAddDialog());
    }

    @Override
    public void refresh() { browser.refresh(); }

    /** Book registration form with a cover picker. The dialog re-opens with the typed values if something is invalid. */
    private void showAddDialog() {
        JTextField title = Theme.field(24);
        JTextField author = Theme.field(24);
        JComboBox<String> category = new JComboBox<String>(new String[] {
                "Fiction", "Non-fiction", "History", "Technology", "Education", "Science", "Children", "Reference" });
        category.setEditable(true);
        category.setFont(Theme.font(Font.PLAIN, 14));
        JSpinner copies = new JSpinner(new SpinnerNumberModel(1, 1, 99, 1));
        copies.setFont(Theme.font(Font.PLAIN, 14));

        final File[] chosen = new File[1];
        JLabel preview = new JLabel("No cover", SwingConstants.CENTER);
        preview.setPreferredSize(new Dimension(110, 154));
        preview.setBorder(BorderFactory.createLineBorder(Theme.FIELD_BORDER));
        preview.setFont(Theme.font(Font.PLAIN, 12));
        preview.setForeground(Theme.MUTED);
        JButton choose = Theme.smallButton("Choose cover image\u2026");
        choose.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setFileFilter(new FileNameExtensionFilter("Images (png, jpg, gif)", "png", "jpg", "jpeg", "gif"));
            if (fc.showOpenDialog(choose) != JFileChooser.APPROVE_OPTION) return;
            BufferedImage img = Covers.fromFile(fc.getSelectedFile(), 110, 154);
            if (img == null) {
                Theme.error(choose, "That file is not a readable image.");
                return;
            }
            chosen[0] = fc.getSelectedFile();
            preview.setText("");
            preview.setIcon(new ImageIcon(img));
        });
        JPanel coverRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        coverRow.setOpaque(false);
        coverRow.add(preview);
        coverRow.add(choose);

        JPanel form = Theme.column();
        form.add(Theme.formRow("Title", title));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.formRow("Author", author));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.formRow("Category", category));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.formRow("Number of copies", copies));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.formRow("Cover image (optional)", coverRow));

        while (true) {
            int result = JOptionPane.showConfirmDialog(this, form, "Register a book",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result != JOptionPane.OK_OPTION) return;
            try {
                Book b = service.addBook(title.getText(), author.getText(),
                        String.valueOf(category.getEditor().getItem()), (Integer) copies.getValue(), chosen[0]);
                Theme.info(this, "Registered \"" + b.getTitle() + "\".\nBook ID: " + b.getCode());
                refresh();
                return;
            } catch (LibraryException e) {
                Theme.error(this, e.getMessage());
            }
        }
    }
}