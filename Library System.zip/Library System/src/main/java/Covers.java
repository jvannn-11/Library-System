import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/** Book cover images: saving uploads, loading, and generated covers for books without a picture. */
public final class Covers {
    private Covers() { }

    private static final File DIR = new File(System.getProperty("user.home"), "LibrarySystem/covers");
    private static final Map<String, BufferedImage> CACHE = new HashMap<String, BufferedImage>();
    private static final Color[][] PALETTE = {
            { new Color(0x0F766E), new Color(0x2DD4BF) }, { new Color(0x1D4ED8), new Color(0x60A5FA) },
            { new Color(0x9A3412), new Color(0xFB923C) }, { new Color(0x6D28D9), new Color(0xA78BFA) },
            { new Color(0xBE185D), new Color(0xF472B6) }, { new Color(0x166534), new Color(0x4ADE80) }
    };

    /** Copies a picked image into the covers folder (400x560 PNG). Returns the stored file name, or "" for none. */
    public static String save(File src) throws LibraryException {
        if (src == null) return "";
        try {
            BufferedImage img = ImageIO.read(src);
            if (img == null) throw new LibraryException("That file is not a readable image (use PNG, JPG or GIF).");
            DIR.mkdirs();
            String name = "cover_" + System.currentTimeMillis() + ".png";
            ImageIO.write(fill(img, 400, 560), "png", new File(DIR, name));
            return name;
        } catch (IOException e) {
            throw new LibraryException("Could not save the image: " + e.getMessage());
        }
    }

    /** For previews before saving. Returns null if the file is not an image. */
    public static BufferedImage fromFile(File f, int w, int h) {
        try {
            BufferedImage src = ImageIO.read(f);
            return src == null ? null : fill(src, w, h);
        } catch (IOException e) {
            return null;
        }
    }

    public static BufferedImage load(Book b, int w, int h) {
        String key = b.getBookId() + "|" + b.getImagePath() + "|" + w + "x" + h;
        BufferedImage img = CACHE.get(key);
        if (img != null) return img;
        if (!b.getImagePath().isEmpty()) {
            try {
                File f = new File(DIR, b.getImagePath());
                if (f.isFile()) {
                    BufferedImage src = ImageIO.read(f);
                    if (src != null) img = fill(src, w, h);
                }
            } catch (IOException ignored) { }
        }
        if (img == null) img = placeholder(b, w, h);
        CACHE.put(key, img);
        return img;
    }

    /** Scales to cover the w x h box and crops the centre. */
    private static BufferedImage fill(BufferedImage src, int w, int h) {
        double s = Math.max((double) w / src.getWidth(), (double) h / src.getHeight());
        int nw = (int) Math.ceil(src.getWidth() * s), nh = (int) Math.ceil(src.getHeight() * s);
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(src, (w - nw) / 2, (h - nh) / 2, nw, nh, null);
        g.dispose();
        return out;
    }

    private static BufferedImage placeholder(Book b, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        Color[] p = PALETTE[(b.getTitle().hashCode() & 0x7fffffff) % PALETTE.length];
        g.setPaint(new GradientPaint(0, 0, p[0], w, h, p[1]));
        g.fillRect(0, 0, w, h);
        g.setColor(new Color(255, 255, 255, 38));
        g.fillOval(-w / 3, h / 2, w, w);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Serif", Font.BOLD, Math.max(16, w / 3)));
        FontMetrics fm = g.getFontMetrics();
        String ini = initials(b.getTitle());
        g.drawString(ini, (w - fm.stringWidth(ini)) / 2, h / 2 + fm.getAscent() / 3);
        g.setColor(new Color(255, 255, 255, 200));
        g.setFont(Theme.font(Font.PLAIN, Math.max(10, w / 14)));
        fm = g.getFontMetrics();
        String cat = b.getCategory();
        g.drawString(cat, (w - fm.stringWidth(cat)) / 2, h - 16);
        g.dispose();
        return out;
    }

    private static String initials(String title) {
        StringBuilder sb = new StringBuilder();
        for (String word : title.trim().split("\\s+")) {
            if (!word.isEmpty() && sb.length() < 2) sb.append(Character.toUpperCase(word.charAt(0)));
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }
}