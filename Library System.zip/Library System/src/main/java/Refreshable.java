/** Every screen implements this so MainFrame can reload its data when it is shown. */
public interface Refreshable {
    void refresh();
}
