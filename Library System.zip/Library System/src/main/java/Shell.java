import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

/** Shared window layout for the admin and the member window: sidebar, top bar and animated pages. */
public abstract class Shell extends JFrame {
    private final CardLayout cards = new CardLayout();
    private final FadePanel content = new FadePanel(cards);
    private final Map<String, Refreshable> screens = new LinkedHashMap<String, Refreshable>();
    private final Map<String, Sidebar.NavButton> navButtons = new LinkedHashMap<String, Sidebar.NavButton>();
    private final Sidebar sidebar;
    private String currentKey = null;

    protected Shell(String subtitle) {
        super("The Library");
        sidebar = new Sidebar(subtitle);
    }

    protected void addScreen(String key, String label, int icon, JPanel panel) {
        Sidebar.NavButton b = new Sidebar.NavButton(label, icon);
        b.addActionListener(e -> show(key));
        sidebar.addItem(b);
        navButtons.put(key, b);
        screens.put(key, (Refreshable) panel);
        content.add(panel, key);
    }

    /** Call once, after every addScreen. */
    protected void finish(String name, String role, Runnable onLogout) {
        sidebar.addFooter("Signed in as " + name, () -> {
            dispose();
            onLogout.run();
        });

        Backdrop.Panel right = new Backdrop.Panel(new BorderLayout());
        right.add(new TopBar(name, role, () -> App.toggleTheme(currentKey)), BorderLayout.NORTH);
        right.add(content, BorderLayout.CENTER);

        setLayout(new BorderLayout());
        add(sidebar, BorderLayout.WEST);
        add(right, BorderLayout.CENTER);
        setMinimumSize(new Dimension(1100, 700));
        setSize(1280, 820);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    /** Switch page, reload its data and play the reveal animation. */
    public void show(String key) {
        currentKey = key;
        cards.show(content, key);
        for (Map.Entry<String, Sidebar.NavButton> e : navButtons.entrySet()) {
            e.getValue().setActive(e.getKey().equals(key));
        }
        screens.get(key).refresh();
        content.play();
    }
}