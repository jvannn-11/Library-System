import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

/** "Trending this month": the most borrowed books, as a row of cards. */
public class TrendingStrip extends Theme.RoundedPanel {
    private final LibraryService service;
    private final Consumer<Book> onClick;
    private final JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 0));

    public TrendingStrip(LibraryService service, Consumer<Book> onClick) {
        super(Color.WHITE, Theme.BORDER, 14);
        this.service = service;
        this.onClick = onClick;
        setLayout(new BorderLayout(0, 12));
        setBorder(new EmptyBorder(18, 24, 18, 24));
        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.add(Theme.cardTitle("Trending this month"), BorderLayout.WEST);
        head.add(Theme.label("Most borrowed in the last 30 days", 13, Font.PLAIN, Theme.MUTED), BorderLayout.EAST);
        row.setOpaque(false);
        add(head, BorderLayout.NORTH);
        add(row, BorderLayout.CENTER);
    }

    public void refresh() {
        row.removeAll();
        try {
            List<LibraryService.Trend> list = service.trending(5, 30);
            if (list.isEmpty()) row.add(Theme.label("Nothing is trending yet.", 14, Font.PLAIN, Theme.MUTED));
            int rank = 1;
            for (LibraryService.Trend t : list) {
                BookCard c = new BookCard(t.book, 140, 170, onClick);
                c.setBadge("#" + rank + " \u00B7 " + t.borrows + (t.borrows == 1 ? " borrow" : " borrows"));
                row.add(c);
                rank++;
            }
        } catch (LibraryException e) {
            row.add(Theme.label(e.getMessage(), 13, Font.PLAIN, Theme.ERR_FG));
        }
        revalidate();
        repaint();
    }
}