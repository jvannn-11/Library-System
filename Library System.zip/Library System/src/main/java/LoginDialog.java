import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Sign-in for the librarian and for members. */
public class LoginDialog extends JDialog {
    private Account account = null;
    private int attempts = 0;

    private LoginDialog(LibraryService service) {
        super((Frame) null, "Sign in", true);
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG);
        root.setBorder(new EmptyBorder(28, 32, 28, 32));

        JPanel form = Theme.column();
        JLabel brand = Theme.label("The Library", 24, Font.BOLD, Theme.SIDEBAR);
        brand.setFont(new Font("Serif", Font.BOLD, 26));
        brand.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(brand);
        form.add(Theme.fill(Theme.subtitle("Librarians and members sign in here")));
        form.add(Box.createVerticalStrut(18));

        JTextField user = Theme.field(18);
        JPasswordField pass = new JPasswordField(18);
        pass.setFont(Theme.font(Font.PLAIN, 14));
        pass.setBorder(user.getBorder());
        JLabel error = Theme.label(" ", 13, Font.PLAIN, Theme.ERR_FG);
        error.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton signIn = Theme.button("Sign in");

        form.add(Theme.formRow("Username", user));
        form.add(Box.createVerticalStrut(12));
        form.add(Theme.formRow("Password", pass));
        form.add(Box.createVerticalStrut(8));
        form.add(error);
        form.add(Box.createVerticalStrut(8));
        form.add(Theme.fill(signIn));
        form.add(Box.createVerticalStrut(12));
        form.add(Theme.fill(Theme.label("<html>Admin: " + Database.DEFAULT_USER + " / " + Database.DEFAULT_PASSWORD
                + "<br>Member: juan / member123</html>", 12, Font.PLAIN, Theme.MUTED)));

        signIn.addActionListener(e -> {
            try {
                Account a = service.login(user.getText(), new String(pass.getPassword()));
                if (a != null) {
                    account = a;
                    dispose();
                } else if (++attempts >= 5) {
                    System.exit(0);
                } else {
                    error.setText("Wrong username or password (" + (5 - attempts) + " tries left).");
                    pass.setText("");
                }
            } catch (LibraryException ex) {
                error.setText(ex.getMessage());
            }
        });
        getRootPane().setDefaultButton(signIn);
        root.add(form);
        setContentPane(root);
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    /** Shows the dialog. Returns the signed-in account, or null if the window was closed. */
    public static Account prompt(LibraryService service) {
        LoginDialog d = new LoginDialog(service);
        d.setVisible(true);
        return d.account;
    }
}