/** Forgiving search: "jdc" finds "Juan Dela Cruz", "noli" finds "Noli Me Tangere". 0 = no match. */
public final class Fuzzy {
    private Fuzzy() { }

    public static int score(String query, String... fields) {
        String q = query == null ? "" : query.trim().toLowerCase();
        if (q.isEmpty()) return 1;
        int best = 0;
        for (String f : fields) {
            if (f == null) continue;
            String s = f.toLowerCase();
            int idx = s.indexOf(q);
            if (idx >= 0) best = Math.max(best, 100 - Math.min(idx, 40) + (idx == 0 ? 10 : 0));
            else if (allWords(s, q)) best = Math.max(best, 70);
            else if (subsequence(s, q.replace(" ", ""))) best = Math.max(best, 40);
        }
        return best;
    }

    private static boolean allWords(String text, String q) {
        for (String w : q.split("\\s+")) if (!text.contains(w)) return false;
        return true;
    }

    private static boolean subsequence(String text, String q) {
        int i = 0;
        for (int k = 0; k < text.length() && i < q.length(); k++) {
            if (text.charAt(k) == q.charAt(i)) i++;
        }
        return i == q.length();
    }
}