import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.function.Consumer;

/** Search box + category pills + "available only" + the book grid. Used by the admin Catalog and the member Browse screen. */
public class BookBrowser extends JPanel {
    private final LibraryService service;
    private final Consumer<Book> onClick, onBorrow;
    private final JTextField search = Theme.searchField(26, "Search title, author or category");
    private final JCheckBox availableOnly = new JCheckBox("Available only");
    private final JPanel pills = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
    private final BookGrid grid = new BookGrid();
    private List<Book> current = new ArrayList<Book>();
    private List<String> lastCats = new ArrayList<String>();
    private String category = null;

    public BookBrowser(LibraryService service, Consumer<Book> onClick) {
        this(service, onClick, null);
    }

    /** onBorrow (optional) adds a quick Borrow button that slides up on each available book. */
    public BookBrowser(LibraryService service, Consumer<Book> onClick, Consumer<Book> onBorrow) {
        this.service = service;
        this.onClick = onClick;
        this.onBorrow = onBorrow;
        setOpaque(false);
        setLayout(new BorderLayout(0, 16));

        availableOnly.setOpaque(false);
        availableOnly.setFont(Theme.font(Font.PLAIN, 13));
        availableOnly.setForeground(Theme.INK);
        availableOnly.setFocusPainted(false);
        availableOnly.addActionListener(e -> applyFilter());

        JPanel top = Theme.column();
        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        row1.setOpaque(false);
        row1.setAlignmentX(Component.LEFT_ALIGNMENT);
        row1.add(search);
        row1.add(availableOnly);
        pills.setOpaque(false);
        pills.setAlignmentX(Component.LEFT_ALIGNMENT);
        top.add(row1);
        top.add(Box.createVerticalStrut(12));
        top.add(pills);
        add(top, BorderLayout.NORTH);
        add(Ui.scroll(grid), BorderLayout.CENTER);

        Theme.onChange(search, this::refresh);
    }

    public void refresh() {
        List<Book> every;
        try {
            every = service.listBooks("");
            current = service.listBooks(search.getText());
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
            return;
        }
        TreeSet<String> set = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
        for (Book b : every) if (!b.getCategory().isEmpty()) set.add(b.getCategory());
        List<String> cats = new ArrayList<String>(set);
        if (!cats.equals(lastCats)) {
            lastCats = cats;
            rebuildPills();
        }
        applyFilter();
    }

    private void rebuildPills() {
        if (category != null && !lastCats.contains(category)) category = null;
        pills.removeAll();
        ButtonGroup group = new ButtonGroup();
        addPill("All", null, group);
        for (String c : lastCats) addPill(c, c, group);
        pills.revalidate();
        pills.repaint();
    }

    private void addPill(String label, String value, ButtonGroup group) {
        Ui.Pill p = new Ui.Pill(label);
        p.setSelected(value == null ? category == null : value.equals(category));
        group.add(p);
        p.addActionListener(e -> { category = value; applyFilter(); });
        pills.add(p);
    }

    private void applyFilter() {
        List<Book> out = new ArrayList<Book>();
        for (Book b : current) {
            if (category != null && !category.equalsIgnoreCase(b.getCategory())) continue;
            if (availableOnly.isSelected() && !b.isAvailable()) continue;
            out.add(b);
        }
        grid.setBooks(out, onClick, onBorrow);
    }
}