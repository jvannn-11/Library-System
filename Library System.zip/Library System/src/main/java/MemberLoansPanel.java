import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Member screen: every book they borrowed, due dates, status and fines. */
public class MemberLoansPanel extends JPanel implements Refreshable {
    private static final DateTimeFormatter SHORT = DateTimeFormatter.ofPattern("MMM d");
    private final LibraryService service;
    private final Account account;
    private final JLabel out = Theme.big(Theme.INK);
    private final JLabel late = Theme.big(Theme.ERR_FG);
    private final JLabel fines = Theme.big(Theme.INK);
    private final DefaultTableModel model = Theme.model("Book", "Borrowed", "Due", "Returned", "Status", "Fine");
    private final JTable table = Theme.table(model);

    public MemberLoansPanel(LibraryService service, Account account) {
        this.service = service;
        this.account = account;
        setLayout(new BorderLayout());
        setOpaque(false);

        JPanel page = Theme.page();
        page.add(Theme.pageHeader("My books",
                Theme.subtitle("Everything you have borrowed, with due dates and fines."), null), BorderLayout.NORTH);
        JPanel body = new JPanel(new BorderLayout(0, 24));
        body.setOpaque(false);
        JPanel stats = new JPanel(new GridLayout(1, 3, 16, 0));
        stats.setOpaque(false);
        stats.add(Theme.statCard("Books out", out));
        stats.add(Theme.statCard("Overdue", late));
        stats.add(Theme.statCard("Fines owed", fines));
        body.add(stats, BorderLayout.NORTH);

        Theme.setWidths(table, 320, 110, 110, 110, 170, 110);
        body.add(Theme.tableCard(table), BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        add(page);
    }

    @Override
    public void refresh() {
        LocalDate today = LocalDate.now();
        try {
            Member me = service.findMember(Member.code(account.getMemberId()));
            if (me == null) return;
            out.setText(me.getActiveLoans() + " of " + Loan.MAX_LOANS);
            late.setText(String.valueOf(me.getOverdueLoans()));
            fines.setText(Theme.money(me.getFineOwed()));

            List<Loan> mine = service.loansForMember(me.getMemberId());
            model.setRowCount(0);
            for (Loan l : mine) {
                Theme.Chip status;
                if (l.isReturned()) {
                    status = (l.fine(today) > 0 && !l.isFinePaid())
                            ? new Theme.Chip("Fine unpaid", Theme.ERR) : new Theme.Chip("Returned", Theme.NEUTRAL);
                } else {
                    status = new Theme.Chip(Ui.dueText(l, today), Ui.dueKind(l, today));
                }
                String fine = l.fine(today) > 0 ? (l.isFinePaid() ? "Paid" : Theme.money(l.fine(today))) : "\u2014";
                model.addRow(new Object[] {
                        "<html><b>" + Ui.esc(l.getBookTitle()) + "</b><br><font color='#4B5563' size='2'>"
                                + Book.code(l.getBookId()) + "</font></html>",
                        l.getBorrowDate().format(SHORT),
                        l.getDueDate().format(SHORT),
                        l.isReturned() ? l.getReturnDate().format(SHORT) : "\u2014",
                        status,
                        fine
                });
            }
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
    }
}