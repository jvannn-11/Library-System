/** A problem the librarian can understand (shown in a dialog box). */
public class LibraryException extends Exception {
    public LibraryException(String message) {
        super(message);
    }
}
