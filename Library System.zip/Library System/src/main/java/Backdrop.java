import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

/** The soft colourful gradient behind every page. Drawn small and stretched, so it stays fast. */
public final class Backdrop {
    private Backdrop() { }

    private static final int SC = 4;
    private static BufferedImage cache;
    private static int cw, ch;
    private static boolean cacheDark;

    private static BufferedImage image(int w, int h) {
        boolean dark = Theme.isDark();
        if (cache != null && cw == w && ch == h && cacheDark == dark) return cache;
        int iw = Math.max(1, w / SC + 2), ih = Math.max(1, h / SC + 2);
        BufferedImage img = new BufferedImage(iw, ih, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(new GradientPaint(0, 0, dark ? new Color(0x0B1413) : new Color(0xF2FAF8),
                iw, ih, dark ? new Color(0x0F1A24) : new Color(0xEEF1FB)));
        g.fillRect(0, 0, iw, ih);
        float big = Math.max(iw, ih);
        blob(g, iw, ih, iw * 0.90f, ih * 0.04f, big * 0.46f, dark ? new Color(0x14B8A6) : new Color(0x2DD4BF), dark ? 70 : 95);
        blob(g, iw, ih, iw * 0.08f, ih * 0.96f, big * 0.42f, dark ? new Color(0x7C3AED) : new Color(0xA78BFA), dark ? 60 : 75);
        blob(g, iw, ih, iw * 0.55f, ih * 0.60f, big * 0.30f, dark ? new Color(0xF59E0B) : new Color(0xFBBF24), dark ? 18 : 45);
        g.dispose();
        cache = img;
        cw = w;
        ch = h;
        cacheDark = dark;
        return img;
    }

    private static void blob(Graphics2D g, int iw, int ih, float cx, float cy, float r, Color c, int alpha) {
        Color in = new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha);
        Color out = new Color(c.getRed(), c.getGreen(), c.getBlue(), 0);
        g.setPaint(new RadialGradientPaint(new Point2D.Float(cx, cy), r, new float[] { 0f, 1f }, new Color[] { in, out }));
        g.fillRect(0, 0, iw, ih);
    }

    /** Paints the part of the window backdrop that lies behind rectangle (x, y, w, h) of component c. */
    public static void draw(Graphics g, JComponent c, int x, int y, int w, int h) {
        JRootPane root = c.getRootPane();
        if (root == null || root.getWidth() <= 0) {
            g.setColor(Theme.BG);
            g.fillRect(x, y, w, h);
            return;
        }
        Point o = SwingUtilities.convertPoint(c, 0, 0, root);
        BufferedImage img = image(root.getWidth(), root.getHeight());
        Graphics2D g2 = (Graphics2D) g.create();
        g2.clipRect(x, y, w, h);
        g2.translate(-o.x, -o.y);
        g2.scale(SC, SC);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img, 0, 0, null);
        g2.dispose();
    }

    /** A panel that paints the backdrop as its background. */
    public static class Panel extends JPanel {
        public Panel(LayoutManager layout) {
            super(layout);
            setOpaque(true);
        }

        @Override
        protected void paintComponent(Graphics g) {
            draw(g, this, 0, 0, getWidth(), getHeight());
        }
    }
}