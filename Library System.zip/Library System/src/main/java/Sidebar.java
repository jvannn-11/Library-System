
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

/**
 * The dark left menu with icons.
 * It can collapse to icons only with a smooth slide.
 */
public class Sidebar extends JPanel {

    static final int WIDE = 232;
    static final int NARROW = 76;

    static boolean collapsedPref = false;

    private float p = collapsedPref ? 1f : 0f;
    private float target = p;

    private final javax.swing.Timer timer =
            new javax.swing.Timer(15, e -> step());

    private final List<NavButton> buttons =
            new ArrayList<NavButton>();

    private JLabel who;
    private NavButton collapseBtn;

    public Sidebar(String subtitle) {

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(true);
        setBorder(new EmptyBorder(24, 16, 18, 16));

        applyWidth();

        add(new Brand(subtitle));
        add(Box.createVerticalStrut(22));
    }

    public void addItem(NavButton b) {

        b.setCollapse(p);

        buttons.add(b);

        add(b);
        add(Box.createVerticalStrut(6));
    }

    public void addFooter(String text, Runnable onLogout) {

        add(Box.createVerticalGlue());

        who = Theme.label(
                text,
                13,
                Font.PLAIN,
                Theme.SIDE_MUTED
        );

        who.setBorder(new EmptyBorder(0, 12, 8, 0));
        who.setAlignmentX(Component.LEFT_ALIGNMENT);
        who.setVisible(p < 0.45f);

        add(who);

        boolean narrow = p > 0.5f;

        collapseBtn = new NavButton(
                narrow ? "Expand menu" : "Collapse menu",
                narrow ? Icons.CHEVRON_RIGHT : Icons.CHEVRON_LEFT
        );

        collapseBtn.setCollapse(p);

        collapseBtn.addActionListener(e -> toggle());

        buttons.add(collapseBtn);
        add(collapseBtn);
        add(Box.createVerticalStrut(6));

        NavButton logout = new NavButton(
                "Log out",
                Icons.LOGOUT
        );

        logout.setCollapse(p);
        logout.addActionListener(e -> onLogout.run());

        buttons.add(logout);
        add(logout);
    }

    private void toggle() {

        target = target > 0.5f ? 0f : 1f;

        collapsedPref = target > 0.5f;

        collapseBtn.setIconKind(
                collapsedPref
                        ? Icons.CHEVRON_RIGHT
                        : Icons.CHEVRON_LEFT
        );

        collapseBtn.updateLabel(
                collapsedPref
                        ? "Expand menu"
                        : "Collapse menu"
        );

        timer.start();
    }

    private void applyWidth() {

        float e = p * p * (3f - 2f * p);

        setPreferredSize(
                new Dimension(
                        Math.round(WIDE - (WIDE - NARROW) * e),
                        0
                )
        );
    }

    private void step() {

        float d = 15f / 230f;

        if (p < target) {
            p = Math.min(target, p + d);
        } else if (p > target) {
            p = Math.max(target, p - d);
        }

        applyWidth();

        for (NavButton b : buttons) {
            b.setCollapse(p);
        }

        if (who != null) {
            who.setVisible(p < 0.45f);
        }

        revalidate();
        repaint();

        if (p == target) {
            timer.stop();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {

        Graphics2D g2 = (Graphics2D) g.create();

        g2.setPaint(
                new GradientPaint(
                        0, 0,
                        new Color(0x143A33),
                        0, getHeight(),
                        new Color(0x091A17)
                )
        );

        g2.fillRect(0, 0, getWidth(), getHeight());

        g2.setPaint(
                new RadialGradientPaint(
                        new Point2D.Float(0, getHeight()),
                        Math.max(getWidth(), 320),
                        new float[]{0f, 1f},
                        new Color[]{
                                new Color(20, 184, 166, 70),
                                new Color(20, 184, 166, 0)
                        }
                )
        );

        g2.fillRect(0, 0, getWidth(), getHeight());

        g2.dispose();
    }

    /**
     * Sidebar brand and subtitle.
     */
    private class Brand extends JComponent {

        private final String sub;

        Brand(String sub) {

            this.sub = sub;

            setPreferredSize(new Dimension(200, 44));
            setMaximumSize(
                    new Dimension(Integer.MAX_VALUE, 44)
            );

            setAlignmentX(Component.LEFT_ALIGNMENT);
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            g2.setPaint(
                    new GradientPaint(
                            3, 4,
                            Theme.PRIMARY,
                            39, 40,
                            new Color(0x34D399)
                    )
            );

            g2.fillRoundRect(3, 4, 36, 36, 12, 12);

            Icons.paint(
                    g2,
                    Icons.BOOK,
                    10,
                    11,
                    22,
                    Color.WHITE,
                    false
            );

            float a = Math.max(0f, 1f - p * 1.8f);

            if (a > 0.02f) {

                g2.setComposite(
                        AlphaComposite.getInstance(
                                AlphaComposite.SRC_OVER,
                                a
                        )
                );

                g2.setColor(Color.WHITE);
                g2.setFont(
                        new Font("Serif", Font.BOLD, 21)
                );

                g2.drawString("The Library", 50, 21);

                g2.setColor(Theme.SIDE_MUTED);
                g2.setFont(
                        Theme.font(Font.PLAIN, 11)
                );

                g2.drawString(sub, 50, 36);
            }

            g2.dispose();
        }
    }

    /**
     * Menu button: icon + label.
     * Highlights on hover and fades its label when collapsed.
     */
    static class NavButton extends JButton {

        private final Anim hover = new Anim(this, 160);

        private String label;
        private int icon;
        private boolean active;
        private float collapse;

        NavButton(String text, int icon) {

            super(text);

            this.label = text;
            this.icon = icon;

            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);

            setBorder(new EmptyBorder(11, 14, 11, 14));

            setCursor(
                    new Cursor(Cursor.HAND_CURSOR)
            );

            setAlignmentX(Component.LEFT_ALIGNMENT);

            setPreferredSize(new Dimension(200, 44));

            setMaximumSize(
                    new Dimension(Integer.MAX_VALUE, 44)
            );

            setToolTipText(text);

            addMouseListener(new MouseAdapter() {

                @Override
                public void mouseEntered(MouseEvent e) {
                    hover.setTarget(1);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover.setTarget(0);
                }
            });
        }

        void setActive(boolean a) {
            active = a;
            repaint();
        }

        void setCollapse(float c) {
            collapse = c;
            repaint();
        }

        void setIconKind(int k) {
            icon = k;
            repaint();
        }

        // Renamed to avoid conflict with AbstractButton.setLabel()
        void updateLabel(String s) {
            label = s;
            setToolTipText(s);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {

            float t = hover.eased();

            int w = getWidth();
            int h = getHeight();

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            if (active) {

                g2.setPaint(
                        new GradientPaint(
                                0, 0,
                                new Color(0x1B5E55),
                                w, 0,
                                new Color(0x127E72)
                        )
                );

                g2.fillRoundRect(0, 0, w, h, 12, 12);

                g2.setColor(new Color(0x34D399));

                g2.fillRoundRect(
                        0, 11, 4, h - 22, 4, 4
                );

            } else if (t > 0.01f) {

                g2.setColor(
                        new Color(
                                255, 255, 255,
                                Math.round(26 * t)
                        )
                );

                g2.fillRoundRect(0, 0, w, h, 12, 12);
            }

            int shift = active
                    ? 0
                    : Math.round(3 * t * (1f - collapse));

            Color ic = active
                    ? Color.WHITE
                    : Theme.mix(
                    Theme.SIDE_TEXT,
                    Color.WHITE,
                    t
            );

            Icons.paint(
                    g2,
                    icon,
                    12 + shift,
                    (h - 20) / 2.0,
                    20,
                    ic,
                    false
            );

            float ta = Math.max(0f, 1f - collapse * 1.7f);

            if (ta > 0.02f) {

                g2.setFont(
                        Theme.font(
                                active ? Font.BOLD : Font.PLAIN,
                                14
                        )
                );

                g2.setComposite(
                        AlphaComposite.getInstance(
                                AlphaComposite.SRC_OVER,
                                ta
                        )
                );

                g2.setColor(
                        active
                                ? Color.WHITE
                                : Theme.SIDE_TEXT
                );

                FontMetrics fm = g2.getFontMetrics();

                g2.drawString(
                        label,
                        44 + shift,
                        (h - fm.getHeight()) / 2 + fm.getAscent()
                );
            }

            g2.dispose();
        }
    }
}
