import javax.swing.*;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Dashboard: today's numbers, recent activity, what needs attention, quick actions. */
public class DashboardPanel extends JPanel implements Refreshable {
    private final LibraryService service;
    private final MainFrame frame;
    private final JLabel subtitle = Theme.subtitle(" ");
    private final JLabel titles = Theme.big(Theme.INK);
    private final JLabel members = Theme.big(Theme.INK);
    private final JLabel onLoan = Theme.big(Theme.WARN_FG);
    private final JLabel overdue = Theme.big(Theme.ERR_FG);
    private final JLabel fines = Theme.big(Theme.INK);
    private final JPanel activity = Theme.column();
    private final JPanel attention = Theme.column();

    public DashboardPanel(LibraryService service, MainFrame frame) {
        this.service = service;
        this.frame = frame;
        setLayout(new BorderLayout());
        setOpaque(false);

        JPanel page = Theme.page();
        page.add(Theme.pageHeader("Dashboard", subtitle, null), BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(0, 24));
        body.setOpaque(false);

        JPanel stats = new JPanel(new GridLayout(1, 5, 16, 0));
        stats.setOpaque(false);
        stats.add(Theme.statCard("Titles", titles));
        stats.add(Theme.statCard("Members", members));
        stats.add(Theme.statCard("Books on loan", onLoan));
        stats.add(Theme.statCard("Overdue", overdue));
        stats.add(Theme.statCard("Fines owed", fines));
        body.add(stats, BorderLayout.NORTH);

        JPanel lower = new JPanel(new GridBagLayout());
        lower.setOpaque(false);
        GridBagConstraints gc = new GridBagConstraints();
        gc.anchor = GridBagConstraints.NORTH;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weighty = 1;

        Theme.RoundedPanel left = Theme.card(18, 24);
        left.setLayout(new BorderLayout());
        left.add(activity);
        gc.gridx = 0;
        gc.weightx = 2;
        gc.insets = new Insets(0, 0, 0, 24);
        lower.add(left, gc);

        JPanel right = Theme.column();
        Theme.RoundedPanel att = Theme.card(18, 24);
        att.setLayout(new BorderLayout());
        att.add(attention);
        att.setAlignmentX(Component.LEFT_ALIGNMENT);
        right.add(att);
        right.add(Box.createVerticalStrut(16));

        Theme.RoundedPanel quick = Theme.card(18, 24);
        quick.setLayout(new BoxLayout(quick, BoxLayout.Y_AXIS));
        quick.setAlignmentX(Component.LEFT_ALIGNMENT);
        quick.add(Theme.cardTitle("Quick actions"));
        quick.add(Box.createVerticalStrut(12));
        JButton borrow = Theme.button("Borrow a book");
        JButton register = Theme.outlineButton("Register a member");
        quick.add(Theme.fill(borrow));
        quick.add(Box.createVerticalStrut(10));
        quick.add(Theme.fill(register));
        borrow.addActionListener(e -> frame.show("borrow"));
        register.addActionListener(e -> frame.show("members"));
        right.add(quick);

        gc.gridx = 1;
        gc.weightx = 1;
        gc.insets = new Insets(0, 0, 0, 0);
        lower.add(right, gc);
        body.add(lower, BorderLayout.CENTER);

        page.add(body, BorderLayout.CENTER);
        add(page);
    }

    private JPanel row(String html, String right) {
        JPanel r = new JPanel(new BorderLayout());
        r.setOpaque(false);
        r.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(0, 0, 1, 0, Theme.ROW_LINE), BorderFactory.createEmptyBorder(11, 0, 11, 0)));
        JLabel l = new JLabel("<html>" + html + "</html>");
        l.setFont(Theme.font(Font.PLAIN, 14));
        l.setForeground(Theme.INK);
        r.add(l, BorderLayout.WEST);
        r.add(Theme.label(right, 13, Font.PLAIN, Theme.MUTED), BorderLayout.EAST);
        r.setAlignmentX(Component.LEFT_ALIGNMENT);
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        return r;
    }

    private static String when(LocalDate d, LocalDate today) {
        return d.equals(today) ? "Today" : d.format(DateTimeFormatter.ofPattern("MMM d"));
    }

    @Override
    public void refresh() {
        LocalDate today = LocalDate.now();
        subtitle.setText("Today at a glance \u00B7 " + today.format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")));
        try {
            LibraryService.Stats s = service.getStats();
            titles.setText(String.valueOf(s.titles));
            members.setText(String.valueOf(s.members));
            onLoan.setText(String.valueOf(s.onLoan));
            overdue.setText(String.valueOf(s.overdueLoans));
            fines.setText(Theme.money(s.finesOwed));

            activity.removeAll();
            activity.add(Theme.cardTitle("Recent activity"));
            activity.add(Box.createVerticalStrut(6));
            List<Loan> recent = service.recentLoans(6);
            if (recent.isEmpty()) {
                activity.add(Theme.label("No activity yet.", 14, Font.PLAIN, Theme.MUTED));
            }
            for (Loan l : recent) {
                String verb = l.isReturned() ? " returned " : " borrowed ";
                LocalDate d = l.isReturned() ? l.getReturnDate() : l.getBorrowDate();
                activity.add(row("<b>" + l.getMemberName() + "</b>" + verb + l.getBookTitle(), when(d, today)));
            }

            attention.removeAll();
            attention.add(Theme.cardTitle("Needs attention"));
            attention.add(Box.createVerticalStrut(10));
            List<Loan> rows = service.overdueRows();
            if (rows.isEmpty()) {
                attention.add(Theme.label("Nothing overdue. Great!", 14, Font.PLAIN, Theme.OK_FG));
            }
            for (int i = 0; i < Math.min(3, rows.size()); i++) {
                Loan l = rows.get(i);
                JLabel t = new JLabel("<html><b>" + l.getBookTitle() + "</b><br><font color='#991B1B'>"
                    + l.getMemberName() + " \u00B7 " + l.daysLate(today) + " days late \u00B7 "
                    + Theme.money(l.fine(today)) + "</font></html>");
                t.setFont(Theme.font(Font.PLAIN, 13));
                t.setAlignmentX(Component.LEFT_ALIGNMENT);
                attention.add(t);
                attention.add(Box.createVerticalStrut(8));
            }
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
        revalidate();
        repaint();
    }
}
