import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/** Small shared helpers for the screens. */
final class Ui {
    private Ui() { }

    private static final DateTimeFormatter SHORT = DateTimeFormatter.ofPattern("MMM d");

    static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** A transparent scroll pane with no border. */
    static JScrollPane scroll(JComponent c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBorder(null);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(18);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return sp;
    }

    static String dueText(Loan l, LocalDate today) {
        if (l.isReturned()) return "Returned " + l.getReturnDate().format(SHORT);
        long left = ChronoUnit.DAYS.between(today, l.getDueDate());
        if (left < 0) return (-left) + (left == -1 ? " day late" : " days late");
        if (left == 0) return "Due today";
        return "Due in " + left + (left == 1 ? " day" : " days");
    }

    static int dueKind(Loan l, LocalDate today) {
        if (l.isReturned()) return Theme.NEUTRAL;
        long left = ChronoUnit.DAYS.between(today, l.getDueDate());
        if (left < 0) return Theme.ERR;
        return left <= 3 ? Theme.WARN : Theme.OK;
    }

    /** Rounded category filter button with a smooth hover. */
    static class Pill extends JToggleButton {
        private final Anim hover = new Anim(this, 140);

        Pill(String text) {
            super(text);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setFont(Theme.font(Font.BOLD, 12));
            setBorder(new EmptyBorder(7, 16, 7, 16));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hover.setTarget(1); }
                public void mouseExited(MouseEvent e) { hover.setTarget(0); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            float t = hover.eased();
            int w = getWidth() - 1, h = getHeight() - 1;
            if (isSelected()) {
                g2.setPaint(new GradientPaint(0, 0, Theme.PRIMARY, Math.max(1, w), 0, new Color(0x14A39A)));
                g2.fillRoundRect(0, 0, w, h, h, h);
                setForeground(Color.WHITE);
            } else {
                g2.setColor(Theme.mix(Theme.SURFACE, Theme.SELECT, t));
                g2.fillRoundRect(0, 0, w, h, h, h);
                g2.setColor(Theme.mix(Theme.BORDER, Theme.ACCENT, t));
                g2.drawRoundRect(0, 0, w, h, h, h);
                setForeground(Theme.INK);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }
}