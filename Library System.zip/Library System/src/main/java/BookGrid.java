import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

/** Wrapping grid of BookCards. Put it inside a scroll pane. */
public class BookGrid extends JPanel implements Scrollable {
    public BookGrid() {
        super(new WrapLayout(FlowLayout.LEFT, 18, 18));
        setOpaque(false);
    }

    public void setBooks(List<Book> books, Consumer<Book> onClick) {
        setBooks(books, onClick, null);
    }

    public void setBooks(List<Book> books, Consumer<Book> onClick, Consumer<Book> onBorrow) {
        removeAll();
        if (books.isEmpty()) add(Theme.label("No books found.", 14, Font.PLAIN, Theme.MUTED));
        for (Book b : books) add(new BookCard(b, 176, 210, onClick, onBorrow));
        revalidate();
        repaint();
    }

    public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
    public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 24; }
    public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return r.height; }
    public boolean getScrollableTracksViewportWidth() { return true; }
    public boolean getScrollableTracksViewportHeight() { return false; }
}