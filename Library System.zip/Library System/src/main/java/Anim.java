import javax.swing.*;

/** Drives a value smoothly between 0 and 1, repainting its owner on every step. */
public final class Anim {
    private final JComponent owner;
    private final float step;
    private final javax.swing.Timer timer;
    private float value, target;

    public Anim(JComponent owner, int millis) {
        this.owner = owner;
        this.step = 16f / Math.max(1, millis);
        this.timer = new javax.swing.Timer(16, e -> tick());
    }

    public void setTarget(float t) {
        target = t;
        if (!timer.isRunning()) timer.start();
    }

    /** Set the value immediately, with no animation. */
    public void jump(float v) {
        value = v;
        target = v;
        timer.stop();
        owner.repaint();
    }

    /** Smooth 0..1 value (fast start, gentle stop). */
    public float eased() { return 1f - (1f - value) * (1f - value); }

    private void tick() {
        if (value < target) value = Math.min(target, value + step);
        else if (value > target) value = Math.max(target, value - step);
        owner.repaint();
        if (value == target) timer.stop();
    }
}