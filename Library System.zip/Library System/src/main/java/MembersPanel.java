import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Members: register members with a portal login, look them up, and reset logins. */
public class MembersPanel extends JPanel implements Refreshable {
    private final LibraryService service;
    private final JTextField search = Theme.searchField(24, "Search name or contact");
    private final DefaultTableModel model = Theme.model("ID", "Name", "Contact", "Books out", "Standing", "");
    private final JTable table = Theme.table(model);
    private final JTextField name = Theme.field(16);
    private final JTextField address = Theme.field(16);
    private final JTextField contact = Theme.field(16);
    private final JTextField username = Theme.field(16);
    private final JPasswordField password = new JPasswordField(16);
    private List<Member> shown = new ArrayList<Member>();

    public MembersPanel(LibraryService service) {
        this.service = service;
        setLayout(new BorderLayout());
        setOpaque(false);

        password.setFont(Theme.font(Font.PLAIN, 14));
        password.setBorder(username.getBorder());
        Theme.focusRing(password);

        JPanel page = Theme.page();
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        right.add(search);
        page.add(Theme.pageHeader("Members", Theme.subtitle("Register members and give them a portal login."), right),
                BorderLayout.NORTH);

        Theme.setWidths(table, 80, 230, 130, 90, 150, 120);
        new Theme.ButtonColumn(table, 5, row -> setLogin(row));
        JPanel body = new JPanel(new BorderLayout(24, 0));
        body.setOpaque(false);
        body.add(Theme.tableCard(table), BorderLayout.CENTER);

        Theme.RoundedPanel form = Theme.card(20, 22);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        JButton register = Theme.button("Register member");
        form.add(Theme.cardTitle("Register member"));
        form.add(Box.createVerticalStrut(12));
        form.add(Theme.fill(Theme.formRow("Full name", name)));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.fill(Theme.formRow("Address", address)));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.fill(Theme.formRow("Contact number", contact)));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.fill(Theme.formRow("Username (for member login)", username)));
        form.add(Box.createVerticalStrut(10));
        form.add(Theme.fill(Theme.formRow("Password (min 6 characters)", password)));
        form.add(Box.createVerticalStrut(12));
        Theme.HintBox hint = new Theme.HintBox().wrap(225);
        hint.set("The member signs in to the member portal with this username and password.", Theme.NEUTRAL);
        form.add(Theme.fill(hint));
        form.add(Box.createVerticalStrut(14));
        form.add(Theme.fill(register));

        form.setPreferredSize(new Dimension(320, form.getPreferredSize().height));
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(form, BorderLayout.NORTH);
        body.add(top, BorderLayout.EAST);
        page.add(body, BorderLayout.CENTER);
        add(page);

        Theme.onChange(search, this::refresh);
        register.addActionListener(e -> register());
    }

    private void register() {
        String u = username.getText().trim().toLowerCase();
        String p = new String(password.getPassword());
        if (u.isEmpty() || p.isEmpty()) {
            Theme.error(this, "Please enter a username and a password for the member.");
            return;
        }
        try {
            Member m = service.registerMember(name.getText(), address.getText(), contact.getText(), u, p);
            Theme.info(this, "Registered " + m.getName() + ".\nThey can sign in with username \"" + u + "\".");
            name.setText("");
            address.setText("");
            contact.setText("");
            username.setText("");
            password.setText("");
            refresh();
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
    }

    /** Create a login for an existing member, or reset their password. */
    private void setLogin(int row) {
        if (row < 0 || row >= shown.size()) return;
        Member m = shown.get(row);
        JTextField u = Theme.field(20);
        JPasswordField p = new JPasswordField(20);
        p.setFont(Theme.font(Font.PLAIN, 14));
        p.setBorder(u.getBorder());
        Theme.focusRing(p);
        JPanel f = Theme.column();
        f.add(Theme.formRow("Username", u));
        f.add(Box.createVerticalStrut(10));
        f.add(Theme.formRow("Password (min 6 characters)", p));
        while (true) {
            int r = JOptionPane.showConfirmDialog(this, f, "Member login for " + m.getName(),
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (r != JOptionPane.OK_OPTION) return;
            try {
                service.setMemberLogin(m.getMemberId(), u.getText(), new String(p.getPassword()));
                Theme.info(this, m.getName() + " can now sign in as \"" + u.getText().trim().toLowerCase() + "\".");
                return;
            } catch (LibraryException e) {
                Theme.error(this, e.getMessage());
            }
        }
    }

    @Override
    public void refresh() {
        try {
            shown = service.listMembers(search.getText());
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
            return;
        }
        model.setRowCount(0);
        for (Member m : shown) {
            Theme.Chip standing = m.getFineOwed() > 0
                    ? new Theme.Chip("Fine " + Theme.money(m.getFineOwed()), Theme.ERR)
                    : new Theme.Chip("Good standing", Theme.OK);
            model.addRow(new Object[] {
                    m.getCode(),
                    "<html><b>" + Ui.esc(m.getName()) + "</b><br><font color='#4B5563' size='2'>"
                            + Ui.esc(m.getAddress()) + "</font></html>",
                    m.getContact(),
                    m.getActiveLoans() + " of " + Loan.MAX_LOANS,
                    standing,
                    "Set login"
            });
        }
    }
}