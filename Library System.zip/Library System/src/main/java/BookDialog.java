import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/** Book details with a Borrow button. The admin also picks the member by name and can change the cover or remove the book. */
public final class BookDialog {
    private static final DateTimeFormatter LONG = DateTimeFormatter.ofPattern("MMM d, yyyy");
    private BookDialog() { }

    public static void show(Component parent, LibraryService service, Book book, Account who, Runnable onChange) {
        Window owner = SwingUtilities.getWindowAncestor(parent);
        JDialog d = new JDialog(owner, "Book details", Dialog.ModalityType.APPLICATION_MODAL);
        JPanel root = new JPanel(new BorderLayout(24, 0));
        root.setBackground(Theme.BG);
        root.setBorder(new EmptyBorder(24, 24, 24, 24));

        JLabel cover = new JLabel(new ImageIcon(Covers.load(book, 220, 308)));
        cover.setVerticalAlignment(SwingConstants.TOP);
        root.add(cover, BorderLayout.WEST);

        JPanel info = Theme.column();
        JLabel title = new JLabel("<html><body style='width:300px'>" + Ui.esc(book.getTitle()) + "</body></html>");
        title.setFont(Theme.font(Font.BOLD, 22));
        title.setForeground(Theme.INK);
        info.add(Theme.fill(title));
        info.add(Box.createVerticalStrut(4));
        info.add(Theme.fill(Theme.subtitle("by " + book.getAuthor() + " \u00B7 " + book.getCategory()
                + " \u00B7 " + book.getCode())));
        info.add(Box.createVerticalStrut(16));

        Theme.HintBox avail = new Theme.HintBox().wrap(300);
        if (book.isAvailable()) {
            avail.set("<b>" + book.getAvailableCopies() + " of " + book.getTotalCopies()
                    + " copies available</b>", Theme.OK);
        } else {
            avail.set("<b>No copies available</b> right now", Theme.WARN);
        }
        info.add(Theme.fill(avail));
        info.add(Box.createVerticalStrut(8));
        Theme.HintBox due = new Theme.HintBox().wrap(300);
        due.set("Borrow today and it is due <b>" + LocalDate.now().plusDays(Loan.LOAN_DAYS).format(LONG)
                + "</b> \u00B7 fine " + Theme.money(Loan.FINE_PER_DAY) + " per day late", Theme.NEUTRAL);
        info.add(Theme.fill(due));
        info.add(Box.createVerticalStrut(8));

        if (!who.isAdmin()) {
            try {
                Member me = service.findMember(Member.code(who.getMemberId()));
                if (me != null) {
                    Theme.HintBox mine = new Theme.HintBox().wrap(300);
                    if (me.getOverdueLoans() > 0 || me.getFineOwed() > 0) {
                        mine.set("You have an overdue book or a fine. Return it and settle the fine before borrowing.",
                                Theme.ERR);
                    } else if (me.getActiveLoans() >= Loan.MAX_LOANS) {
                        mine.set("You already have " + Loan.MAX_LOANS + " books out. Return one first.", Theme.WARN);
                    } else {
                        mine.set("You have " + me.getActiveLoans() + " of " + Loan.MAX_LOANS
                                + " books out. You can borrow this one.", Theme.OK);
                    }
                    info.add(Theme.fill(mine));
                }
            } catch (LibraryException ignored) { }
        }
        info.add(Box.createVerticalStrut(16));

        SuggestField member = null;
        if (who.isAdmin()) {
            member = SuggestField.members(service);
            info.add(Theme.fill(Theme.formRow("Borrow for member (type their name)", member)));
            info.add(Box.createVerticalStrut(12));
        }
        final SuggestField memberField = member;

        JButton borrow = Theme.button(who.isAdmin() ? "Borrow for this member" : "Borrow this book");
        if (!book.isAvailable()) {
            borrow.setText("No copies available");
            borrow.setEnabled(false);
        }
        borrow.addActionListener(e -> {
            String memberId = who.isAdmin() ? memberField.idOrNull('M') : Member.code(who.getMemberId());
            if (memberId == null) {
                Theme.error(d, "Type the member's name and pick them from the suggestions.");
                return;
            }
            try {
                Loan l = service.borrowBook(memberId, book.getCode());
                d.dispose();
                Theme.info(parent, l.getMemberName() + " borrowed \"" + l.getBookTitle() + "\". Due on "
                        + l.getDueDate().format(LONG) + ".");
                onChange.run();
            } catch (LibraryException ex) {
                Theme.error(d, ex.getMessage());
            }
        });
        info.add(Theme.fill(borrow));

        if (who.isAdmin()) {
            JButton change = Theme.smallButton("Change cover");
            JButton remove = Theme.smallButton("Remove book");
            change.addActionListener(e -> {
                JFileChooser fc = new JFileChooser();
                fc.setFileFilter(new FileNameExtensionFilter("Images (png, jpg, gif)", "png", "jpg", "jpeg", "gif"));
                if (fc.showOpenDialog(d) != JFileChooser.APPROVE_OPTION) return;
                try {
                    service.setBookCover(book.getBookId(), fc.getSelectedFile());
                    d.dispose();
                    onChange.run();
                } catch (LibraryException ex) {
                    Theme.error(d, ex.getMessage());
                }
            });
            remove.addActionListener(e -> {
                if (!Theme.confirm(d, "Remove \"" + book.getTitle() + "\" from the catalogue?")) return;
                try {
                    service.deleteBook(book.getBookId());
                    d.dispose();
                    onChange.run();
                } catch (LibraryException ex) {
                    Theme.error(d, ex.getMessage());
                }
            });
            JPanel tools = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            tools.setOpaque(false);
            tools.add(change);
            tools.add(remove);
            info.add(Box.createVerticalStrut(12));
            info.add(Theme.fill(tools));
        }
        info.add(Box.createVerticalGlue());

        root.add(info, BorderLayout.CENTER);
        d.setContentPane(root);
        d.setMinimumSize(new Dimension(640, 470));
        d.pack();
        d.setLocationRelativeTo(parent);
        d.setVisible(true);
    }
}