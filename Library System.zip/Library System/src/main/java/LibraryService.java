import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.io.File;
import java.util.function.ToIntFunction;

/**
 * All the library rules and database work live here.
 * The GUI never touches SQL; it calls these methods and shows the messages.
 * Every method opens its own connection with try-with-resources, so nothing leaks.
 */
public class LibraryService {

    /** Numbers for the dashboard. */
    public static class Stats {
        public int titles, members, copiesAvailable, onLoan, overdueLoans;
        public double finesOwed;
        public long longestOverdue;
    }

    private static final String LOAN_SQL =
        "SELECT l.loan_id, l.book_id, b.title, l.member_id, m.name, l.borrow_date, l.due_date, "
      + "l.return_date, l.fine_amount, l.fine_paid FROM loans l "
      + "JOIN books b ON b.book_id = l.book_id JOIN members m ON m.member_id = l.member_id";

    private static final String BOOK_SQL =
        "SELECT b.book_id, b.title, b.author, b.category, b.total_copies, "
      + "b.total_copies - (SELECT COUNT(*) FROM loans l WHERE l.book_id = b.book_id AND l.return_date IS NULL) "
      + "FROM books b WHERE b.active = 1";

    // ------------------------------------------------------------ helpers

    private Connection open() throws LibraryException {
        try {
            return Database.connect();
        } catch (SQLException e) {
            throw new LibraryException("Cannot open the database: " + e.getMessage());
        }
    }

    private static LibraryException db(SQLException e) {
        return new LibraryException("Database error: " + e.getMessage());
    }

    /** Accepts "B001", "b1" or "1". */
    public static int parseId(String text, char prefix) throws LibraryException {
        String t = text == null ? "" : text.trim().toUpperCase();
        if (t.startsWith(String.valueOf(prefix))) {
            t = t.substring(1);
        }
        try {
            int id = Integer.parseInt(t);
            if (id <= 0) throw new NumberFormatException();
            return id;
        } catch (NumberFormatException e) {
            throw new LibraryException("Enter a valid ID such as " + prefix + "001.");
        }
    }

    private static String money(double v) {
        return String.format("PHP %,.2f", v);
    }

    // ------------------------------------------------------------ login
    public Account login(String username, String password) throws LibraryException {
        try (Connection c = open();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT salt, password_hash, role, member_id, username FROM users WHERE lower(username) = lower(?)")) {
            ps.setString(1, username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && PasswordUtil.matches(password, rs.getString(1), rs.getString(2))) {
                    return new Account(rs.getString(5), rs.getString(3), rs.getInt(4));
                }
                return null;
            }
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** Creates or replaces the portal login of an existing member (also works as a password reset). */
    public void setMemberLogin(int memberId, String username, String password) throws LibraryException {
        username = username == null ? "" : username.trim().toLowerCase();
        password = password == null ? "" : password;
        if (!username.matches("[a-z0-9._-]{3,20}")) {
            throw new LibraryException("Username must be 3 to 20 letters, numbers, dots, dashes or underscores.");
        }
        if (password.length() < 6) throw new LibraryException("The password must be at least 6 characters.");
        try (Connection c = open()) {
            c.setAutoCommit(false);
            if (loadMembers(c, memberId).isEmpty()) throw new LibraryException("Member not found.");
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT role, member_id FROM users WHERE lower(username) = ?")) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && !("member".equals(rs.getString(1)) && rs.getInt(2) == memberId)) {
                        throw new LibraryException("That username is already taken.");
                    }
                }
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "DELETE FROM users WHERE role = 'member' AND member_id = ?")) {
                ps.setInt(1, memberId);
                ps.executeUpdate();
            }
            String salt = PasswordUtil.newSalt();
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO users (username, salt, password_hash, role, member_id) VALUES (?,?,?,'member',?)")) {
                ps.setString(1, username);
                ps.setString(2, salt);
                ps.setString(3, PasswordUtil.hash(password, salt));
                ps.setInt(4, memberId);
                ps.executeUpdate();
            }
            c.commit();
        } catch (SQLException e) {
            throw db(e);
        }
    }

    // ------------------------------------------------------------ books

    private List<Book> loadBooks(Connection c) throws SQLException {
        List<Book> out = new ArrayList<Book>();
        try (Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(BOOK_SQL + " ORDER BY b.title COLLATE NOCASE")) {
            while (rs.next()) {
                out.add(new Book(rs.getInt(1), rs.getString(2), rs.getString(3),
                                 rs.getString(4), rs.getInt(5), rs.getInt(6)));
            }
        }
        return out;
    }

    private Book findBook(Connection c, int id) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(BOOK_SQL + " AND b.book_id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Book(rs.getInt(1), rs.getString(2), rs.getString(3),
                                    rs.getString(4), rs.getInt(5), rs.getInt(6));
                }
            }
        }
        return null;
    }

    /** Empty keyword returns every book. */
    public List<Book> listBooks(String keyword) throws LibraryException {
        try (Connection c = open()) {
            List<Book> all = loadBooks(c);
            if (keyword == null || keyword.trim().isEmpty()) return all;
            List<Book> out = new ArrayList<Book>();
            for (Book b : all) {
                if (b.matches(keyword.trim())) out.add(b);
            }
            return out;
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** Returns null if there is no such book. */
    public Book findBook(String idText) throws LibraryException {
        int id = parseId(idText, 'B');
        try (Connection c = open()) {
            return findBook(c, id);
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public Book addBook(String title, String author, String category, int copies) throws LibraryException {
        return addBook(title, author, category, copies, null);
    }

    /** cover may be null. The image is only saved after every check has passed. */
    public Book addBook(String title, String author, String category, int copies, File cover) throws LibraryException {
        title = title == null ? "" : title.trim();
        author = author == null ? "" : author.trim();
        category = category == null ? "" : category.trim();
        if (title.isEmpty()) throw new LibraryException("Please enter the book title.");
        if (author.isEmpty()) throw new LibraryException("Please enter the author.");
        if (copies < 1 || copies > 99) throw new LibraryException("Copies must be between 1 and 99.");
        try (Connection c = open()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT 1 FROM books WHERE active = 1 AND lower(title) = lower(?) AND lower(author) = lower(?)")) {
                ps.setString(1, title);
                ps.setString(2, author);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) throw new LibraryException("This title by " + author + " is already registered.");
                }
            }
            String image = Covers.save(cover);
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO books (title, author, category, total_copies, image_path) VALUES (?,?,?,?,?)")) {
                ps.setString(1, title);
                ps.setString(2, author);
                ps.setString(3, category);
                ps.setInt(4, copies);
                ps.setString(5, image);
                ps.executeUpdate();
            }
            return findBook(c, lastInsertId(c));
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public void setBookCover(int bookId, File cover) throws LibraryException {
        String image = Covers.save(cover);
        try (Connection c = open();
             PreparedStatement ps = c.prepareStatement("UPDATE books SET image_path = ? WHERE book_id = ?")) {
            ps.setString(1, image);
            ps.setInt(2, bookId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** Soft delete: the book disappears from the catalogue but old loan records stay valid. */
    public void deleteBook(int bookId) throws LibraryException {
        try (Connection c = open()) {
            Book b = findBook(c, bookId);
            if (b == null) throw new LibraryException("Book not found.");
            if (b.getAvailableCopies() < b.getTotalCopies()) {
                throw new LibraryException("\"" + b.getTitle() + "\" still has copies on loan. Return them first.");
            }
            try (PreparedStatement ps = c.prepareStatement("UPDATE books SET active = 0 WHERE book_id = ?")) {
                ps.setInt(1, bookId);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw db(e);
        }
    }

    // ------------------------------------------------------------ members

    private List<Member> loadMembers(Connection c, Integer onlyId) throws SQLException {
        LocalDate today = LocalDate.now();
        List<Loan> open = queryLoans(c, "l.return_date IS NULL OR (l.fine_amount > 0 AND l.fine_paid = 0)");
        String sql = "SELECT member_id, name, address, contact FROM members WHERE active = 1"
                   + (onlyId != null ? " AND member_id = ?" : "") + " ORDER BY member_id";
        List<Member> out = new ArrayList<Member>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            if (onlyId != null) ps.setInt(1, onlyId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt(1);
                    int active = 0, overdue = 0;
                    double fine = 0;
                    for (Loan l : open) {
                        if (l.getMemberId() != id) continue;
                        if (!l.isReturned()) {
                            active++;
                            if (l.daysLate(today) > 0) overdue++;
                        }
                        fine += l.fine(today);
                    }
                    out.add(new Member(id, rs.getString(2), rs.getString(3), rs.getString(4), active, overdue, fine));
                }
            }
        }
        return out;
    }

    public List<Member> listMembers(String keyword) throws LibraryException {
        try (Connection c = open()) {
            List<Member> all = loadMembers(c, null);
            if (keyword == null || keyword.trim().isEmpty()) return all;
            List<Member> out = new ArrayList<Member>();
            for (Member m : all) {
                if (m.matches(keyword.trim())) out.add(m);
            }
            return out;
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** Returns null if there is no such member. */
    public Member findMember(String idText) throws LibraryException {
        int id = parseId(idText, 'M');
        try (Connection c = open()) {
            List<Member> l = loadMembers(c, id);
            return l.isEmpty() ? null : l.get(0);
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public Member registerMember(String name, String address, String contact) throws LibraryException {
        return registerMember(name, address, contact, "", "");
    }

    public Member registerMember(String name, String address, String contact,
                                 String username, String password) throws LibraryException {
        name = name == null ? "" : name.trim();
        address = address == null ? "" : address.trim();
        contact = contact == null ? "" : contact.trim();
        username = username == null ? "" : username.trim().toLowerCase();
        password = password == null ? "" : password;
        if (name.isEmpty()) throw new LibraryException("Please enter the member's full name.");
        if (!contact.matches("[0-9+\\- ]{7,15}")) {
            throw new LibraryException("Enter a valid contact number (7 to 15 digits).");
        }
        boolean account = !username.isEmpty() || !password.isEmpty();
        if (account) {
            if (!username.matches("[a-z0-9._-]{3,20}")) {
                throw new LibraryException("Username must be 3 to 20 letters, numbers, dots, dashes or underscores.");
            }
            if (password.length() < 6) throw new LibraryException("The password must be at least 6 characters.");
        }
        try (Connection c = open()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT 1 FROM members WHERE active = 1 AND lower(name) = lower(?) AND contact = ?")) {
                ps.setString(1, name);
                ps.setString(2, contact);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) throw new LibraryException("This member is already registered.");
                }
            }
            if (account) {
                try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM users WHERE lower(username) = ?")) {
                    ps.setString(1, username);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) throw new LibraryException("That username is already taken.");
                    }
                }
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO members (name, address, contact) VALUES (?,?,?)")) {
                ps.setString(1, name);
                ps.setString(2, address);
                ps.setString(3, contact);
                ps.executeUpdate();
            }
            int id = lastInsertId(c);
            if (account) {
                String salt = PasswordUtil.newSalt();
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO users (username, salt, password_hash, role, member_id) VALUES (?,?,?,'member',?)")) {
                    ps.setString(1, username);
                    ps.setString(2, salt);
                    ps.setString(3, PasswordUtil.hash(password, salt));
                    ps.setInt(4, id);
                    ps.executeUpdate();
                }
            }
            c.commit();
            return loadMembers(c, id).get(0);
        } catch (SQLException e) {
            throw db(e);
        }
    }
    /** Gives the sample members a login if they do not have one yet (juan / maria, password member123). */
    public void ensureSampleLogins() throws LibraryException {
        giveLoginIfMissing("Juan Dela Cruz", "juan");
        giveLoginIfMissing("Maria Santos", "maria");
    }

    private void giveLoginIfMissing(String name, String username) throws LibraryException {
        int memberId = -1;
        boolean hasLogin = false;
        try (Connection c = open()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT member_id FROM members WHERE active = 1 AND lower(name) = lower(?)")) {
                ps.setString(1, name);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) memberId = rs.getInt(1);
                }
            }
            if (memberId < 0) return;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT 1 FROM users WHERE lower(username) = ? OR (role = 'member' AND member_id = ?)")) {
                ps.setString(1, username);
                ps.setInt(2, memberId);
                try (ResultSet rs = ps.executeQuery()) {
                    hasLogin = rs.next();
                }
            }
        } catch (SQLException e) {
            throw db(e);
        }
        if (!hasLogin) setMemberLogin(memberId, username, "member123");
    }
    // ------------------------------------------------------------ loans

    private List<Loan> queryLoans(Connection c, String where, Object... params) throws SQLException {
        String sql = LOAN_SQL + (where == null ? "" : " WHERE " + where) + " ORDER BY l.loan_id DESC";
        List<Loan> out = new ArrayList<Loan>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String ret = rs.getString(8);
                    out.add(new Loan(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getString(5),
                            LocalDate.parse(rs.getString(6)), LocalDate.parse(rs.getString(7)),
                            ret == null ? null : LocalDate.parse(ret), rs.getDouble(9), rs.getInt(10) == 1));
                }
            }
        }
        return out;
    }

    private int lastInsertId(Connection c) throws SQLException {
        try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT last_insert_rowid()")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    private int insertLoan(Connection c, int bookId, int memberId, LocalDate borrowDate) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO loans (book_id, member_id, borrow_date, due_date) VALUES (?,?,?,?)")) {
            ps.setInt(1, bookId);
            ps.setInt(2, memberId);
            ps.setString(3, borrowDate.toString());
            ps.setString(4, borrowDate.plusDays(Loan.LOAN_DAYS).toString());
            ps.executeUpdate();
        }
        return lastInsertId(c);
    }

    public Loan borrowBook(String memberText, String bookText) throws LibraryException {
        int mid = parseId(memberText, 'M');
        int bid = parseId(bookText, 'B');
        try (Connection c = open()) {
            c.setAutoCommit(false);   // all-or-nothing
            List<Member> found = loadMembers(c, mid);
            if (found.isEmpty()) {
                throw new LibraryException("Member " + Member.code(mid) + " not found. Please register first.");
            }
            Member m = found.get(0);
            Book b = findBook(c, bid);
            if (b == null) throw new LibraryException("Book " + Book.code(bid) + " not found.");
            if (m.getActiveLoans() >= Loan.MAX_LOANS) {
                throw new LibraryException(m.getName() + " already has " + Loan.MAX_LOANS + " books. Return one first.");
            }
            if (m.getOverdueLoans() > 0) {
                throw new LibraryException(m.getName() + " has an overdue book. Please return it first.");
            }
            if (m.getFineOwed() > 0) {
                throw new LibraryException(m.getName() + " owes " + money(m.getFineOwed()) + ". Settle the fine first.");
            }
            if (!queryLoans(c, "l.member_id = ? AND l.book_id = ? AND l.return_date IS NULL", mid, bid).isEmpty()) {
                throw new LibraryException(m.getName() + " already has this title.");
            }
            if (!b.isAvailable()) {
                throw new LibraryException("No copies of \"" + b.getTitle() + "\" are available right now.");
            }
            int loanId = insertLoan(c, bid, mid, LocalDate.now());
            c.commit();
            return queryLoans(c, "l.loan_id = ?", loanId).get(0);
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** The loan this member currently has for this book, or null. */
    public Loan findOpenLoan(String memberText, String bookText) throws LibraryException {
        int mid = parseId(memberText, 'M');
        int bid = parseId(bookText, 'B');
        try (Connection c = open()) {
            List<Loan> l = queryLoans(c, "l.member_id = ? AND l.book_id = ? AND l.return_date IS NULL", mid, bid);
            return l.isEmpty() ? null : l.get(0);
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public Loan returnBook(String memberText, String bookText) throws LibraryException {
        Loan loan = findOpenLoan(memberText, bookText);
        if (loan == null) throw new LibraryException("This member has not borrowed that book.");
        return returnLoan(loan.getLoanId());
    }

    /** Records the return today and fixes the fine (PHP 5.00 per day late). */
    public Loan returnLoan(int loanId) throws LibraryException {
        try (Connection c = open()) {
            List<Loan> l = queryLoans(c, "l.loan_id = ?", loanId);
            if (l.isEmpty() || l.get(0).isReturned()) throw new LibraryException("This loan is already returned.");
            LocalDate today = LocalDate.now();
            double fine = l.get(0).daysLate(today) * Loan.FINE_PER_DAY;
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE loans SET return_date = ?, fine_amount = ? WHERE loan_id = ?")) {
                ps.setString(1, today.toString());
                ps.setDouble(2, fine);
                ps.setInt(3, loanId);
                ps.executeUpdate();
            }
            return queryLoans(c, "l.loan_id = ?", loanId).get(0);
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public void markFinePaid(int loanId) throws LibraryException {
        try (Connection c = open();
             PreparedStatement ps = c.prepareStatement(
                 "UPDATE loans SET fine_paid = 1 WHERE loan_id = ? AND return_date IS NOT NULL AND fine_amount > 0")) {
            ps.setInt(1, loanId);
            if (ps.executeUpdate() == 0) throw new LibraryException("There is no unpaid fine on this loan.");
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** Books currently out, soonest due date first. */
    public List<Loan> activeLoans() throws LibraryException {
        try (Connection c = open()) {
            List<Loan> l = queryLoans(c, "l.return_date IS NULL");
            l.sort(Comparator.comparing(Loan::getDueDate));
            return l;
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** Late books still out, plus returned books whose fine is not yet paid. */
    public List<Loan> overdueRows() throws LibraryException {
        try (Connection c = open()) {
            List<Loan> l = queryLoans(c,
                "(l.return_date IS NULL AND l.due_date < ?) OR (l.return_date IS NOT NULL AND l.fine_amount > 0 AND l.fine_paid = 0)",
                LocalDate.now().toString());
            l.sort(Comparator.comparing(Loan::getDueDate));
            return l;
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public List<Loan> recentLoans(int limit) throws LibraryException {
        try (Connection c = open()) {
            List<Loan> l = queryLoans(c, null);
            // newest activity first (a return counts as activity on the return date)
            l.sort(Comparator.comparing((Loan x) -> x.isReturned() ? x.getReturnDate() : x.getBorrowDate()).reversed());
            return l.size() > limit ? new ArrayList<Loan>(l.subList(0, limit)) : l;
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public Stats getStats() throws LibraryException {
        Stats s = new Stats();
        LocalDate today = LocalDate.now();
        try (Connection c = open()) {
            List<Book> books = loadBooks(c);
            s.titles = books.size();
            for (Book b : books) s.copiesAvailable += b.getAvailableCopies();
            s.members = loadMembers(c, null).size();
            s.onLoan = queryLoans(c, "l.return_date IS NULL").size();
        } catch (SQLException e) {
            throw db(e);
        }
        for (Loan l : overdueRows()) {
            s.finesOwed += l.fine(today);
            if (!l.isReturned()) {
                s.overdueLoans++;
                s.longestOverdue = Math.max(s.longestOverdue, l.daysLate(today));
            }
        }
        return s;
    }

    // ------------------------------------------------------------ demo data

    /** First run only: a few books, two members and some loans so the screens are not empty. */
    public void loadSampleDataIfEmpty() throws LibraryException {
        try (Connection c = open(); Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT (SELECT COUNT(*) FROM books) + (SELECT COUNT(*) FROM members)")) {
            rs.next();
            if (rs.getInt(1) > 0) return;
        } catch (SQLException e) {
            throw db(e);
        }
        addBook("Noli Me Tangere", "Jose Rizal", "Fiction", 3);
        addBook("El Filibusterismo", "Jose Rizal", "Fiction", 2);
        addBook("Introduction to Java", "Y. Daniel Liang", "Technology", 2);
        addBook("Philippine History", "Teodoro Agoncillo", "History", 1);
        addBook("Basic Mathematics", "Seymour Lipschutz", "Education", 4);
        registerMember("Juan Dela Cruz", "Iloilo City", "09171234567");
        registerMember("Maria Santos", "Jaro, Iloilo", "09181234567");
        LocalDate today = LocalDate.now();
        try (Connection c = open()) {
            insertLoan(c, 1, 1, today);
            insertLoan(c, 3, 1, today.minusDays(2));
            insertLoan(c, 3, 2, today.minusDays(4));
            insertLoan(c, 4, 2, today.minusDays(20));   // 6 days overdue
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** One entry of the trending list. */
    public static class Trend {
        public final Book book;
        public final int borrows;
        public Trend(Book book, int borrows) {
            this.book = book;
            this.borrows = borrows;
        }
    }

    /** Most borrowed books in the last `days` days (falls back to all time if nothing was borrowed recently). */
    public List<Trend> trending(int limit, int days) throws LibraryException {
        try (Connection c = open()) {
            List<Trend> out = collectTrends(c, limit, LocalDate.now().minusDays(days).toString());
            if (out.isEmpty()) out = collectTrends(c, limit, "0000-01-01");
            return out;
        } catch (SQLException e) {
            throw db(e);
        }
    }

    private List<Trend> collectTrends(Connection c, int limit, String since) throws SQLException {
        List<Trend> out = new ArrayList<Trend>();
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT book_id, COUNT(*) AS n FROM loans WHERE borrow_date >= ? "
                        + "GROUP BY book_id ORDER BY n DESC, MAX(loan_id) DESC")) {
            ps.setString(1, since);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next() && out.size() < limit) {
                    Book b = findBook(c, rs.getInt(1));
                    if (b != null) out.add(new Trend(b, rs.getInt(2)));
                }
            }
        }
        return out;
    }

    /** A member's loans: books still out first (soonest due first), then history (newest first). */
    public List<Loan> loansForMember(int memberId) throws LibraryException {
        try (Connection c = open()) {
            List<Loan> all = queryLoans(c, "l.member_id = ?", memberId);   // newest first
            List<Loan> open = new ArrayList<Loan>(), done = new ArrayList<Loan>();
            for (Loan l : all) (l.isReturned() ? done : open).add(l);
            open.sort(Comparator.comparing(Loan::getDueDate));
            open.addAll(done);
            return open;
        } catch (SQLException e) {
            throw db(e);
        }
    }

    private static <T> List<T> rank(List<T> all, ToIntFunction<T> scorer, int limit) {
        List<T> out = new ArrayList<T>(all);
        out.removeIf(x -> scorer.applyAsInt(x) == 0);
        Comparator<T> byScore = Comparator.comparingInt(scorer);
        out.sort(byScore.reversed());
        return out.size() > limit ? new ArrayList<T>(out.subList(0, limit)) : out;
    }

    /** Members whose name, ID or contact shares the typed letters, best match first. */
    public List<Member> suggestMembers(String q, int limit) throws LibraryException {
        try (Connection c = open()) {
            return rank(loadMembers(c, null), m -> Fuzzy.score(q, m.getName(), m.getCode(), m.getContact()), limit);
        } catch (SQLException e) {
            throw db(e);
        }
    }

    /** Books whose title, author, category or ID shares the typed letters, best match first. */
    public List<Book> suggestBooks(String q, int limit) throws LibraryException {
        try (Connection c = open()) {
            return rank(loadBooks(c), b -> Fuzzy.score(q, b.getTitle(), b.getAuthor(), b.getCode(), b.getCategory()), limit);
        } catch (SQLException e) {
            throw db(e);
        }
    }
}
