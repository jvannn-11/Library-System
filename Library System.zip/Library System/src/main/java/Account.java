/** Who is signed in: an admin (librarian) or a member. */
public class Account {
    public static final String ADMIN = "admin", MEMBER = "member";
    private final String username, role;
    private final int memberId;

    public Account(String username, String role, int memberId) {
        this.username = username;
        this.role = role;
        this.memberId = memberId;
    }

    public static Account admin() { return new Account("librarian", ADMIN, 0); }

    public String getUsername() { return username; }
    public int getMemberId()    { return memberId; }
    public boolean isAdmin()    { return ADMIN.equals(role); }
}