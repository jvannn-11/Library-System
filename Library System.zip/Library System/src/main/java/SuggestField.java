import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/** A text box that shows matching suggestions while you type names or titles. */
public class SuggestField extends JTextField {

    public static class Item {
        final String code, title, detail;
        public Item(String code, String title, String detail) {
            this.code = code;
            this.title = title;
            this.detail = detail;
        }
    }

    private static final DateTimeFormatter SHORT = DateTimeFormatter.ofPattern("MMM d");

    private final Function<String, List<Item>> source;
    private final String placeholder;
    private final DefaultListModel<Item> model = new DefaultListModel<Item>();
    private final JList<Item> list = new JList<Item>(model);
    private final JPopupMenu popup = new JPopupMenu();
    private final List<Runnable> listeners = new ArrayList<Runnable>();
    private String selectedCode;
    private boolean updating;

    public SuggestField(int columns, String placeholder, Function<String, List<Item>> source) {
        super(columns);
        this.source = source;
        this.placeholder = placeholder;
        setFont(Theme.font(Font.PLAIN, 14));
        setForeground(Theme.INK);
        setBackground(Theme.FIELD_BG);
        setCaretColor(Theme.INK);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.FIELD_BORDER), new EmptyBorder(9, 12, 9, 12)));
        Theme.focusRing(this);

        list.setFocusable(false);
        list.setBackground(Theme.SURFACE);
        list.setFixedCellHeight(50);
        list.setCellRenderer(new Renderer());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        popup.setFocusable(false);
        popup.setBackground(Theme.SURFACE);
        popup.setBorder(BorderFactory.createLineBorder(Theme.FIELD_BORDER));
        popup.add(list);

        getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { typed(); }
            public void removeUpdate(DocumentEvent e) { typed(); }
            public void changedUpdate(DocumentEvent e) { typed(); }
        });
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) { keys(e); }
        });
        addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { popup.setVisible(false); }
        });
        list.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                int i = list.locationToIndex(e.getPoint());
                if (i >= 0) list.setSelectedIndex(i);
            }
        });
        list.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = list.locationToIndex(e.getPoint());
                if (i >= 0) pick(model.get(i));
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getText().isEmpty() && !hasFocus()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(Theme.MUTED);
            g2.setFont(getFont());
            g2.drawString(placeholder, getInsets().left, (getHeight() + g2.getFontMetrics().getAscent()
                    - g2.getFontMetrics().getDescent()) / 2);
            g2.dispose();
        }
    }

    /** Called after the text or the picked item changes. */
    public void addChangeListener(Runnable r) { listeners.add(r); }

    /**
     * The ID behind what the user chose or typed, or null if it is not clear yet.
     * Clear means: picked from the list, only one match, or the typed text exactly equals the top match.
     */
    public String idOrNull(char prefix) {
        if (selectedCode != null) return selectedCode;
        String t = getText().trim();
        if (t.isEmpty()) return null;
        List<Item> found = source.apply(t);
        if (found.size() == 1) return found.get(0).code;
        if (!found.isEmpty() && found.get(0).title.equalsIgnoreCase(t)
                && (found.size() == 1 || !found.get(1).title.equalsIgnoreCase(t))) {
            return found.get(0).code;
        }
        return t.matches("(?i)" + prefix + "?\\d+") ? t : null;
    }

    private void fire() {
        for (Runnable r : listeners) r.run();
    }

    private void typed() {
        if (updating) return;
        selectedCode = null;
        fire();
        String q = getText().trim();
        if (q.isEmpty() || !isShowing() || !hasFocus()) {
            popup.setVisible(false);
            return;
        }
        model.clear();
        for (Item it : source.apply(q)) model.addElement(it);
        if (model.isEmpty()) {
            popup.setVisible(false);
            return;
        }
        list.setSelectedIndex(0);
        popup.setPopupSize(Math.max(getWidth(), 280), Math.min(model.size(), 6) * 50 + 2);
        popup.show(this, 0, getHeight());
    }

    private void keys(KeyEvent e) {
        if (!popup.isVisible()) return;
        int i = list.getSelectedIndex();
        switch (e.getKeyCode()) {
            case KeyEvent.VK_DOWN:
                list.setSelectedIndex(Math.min(i + 1, model.size() - 1));
                e.consume();
                break;
            case KeyEvent.VK_UP:
                list.setSelectedIndex(Math.max(i - 1, 0));
                e.consume();
                break;
            case KeyEvent.VK_ENTER:
                if (i >= 0) { pick(model.get(i)); e.consume(); }
                break;
            case KeyEvent.VK_ESCAPE:
                popup.setVisible(false);
                e.consume();
                break;
            default:
                break;
        }
    }

    private void pick(Item it) {
        selectedCode = it.code;
        updating = true;
        setText(it.title);
        updating = false;
        popup.setVisible(false);
        fire();
    }

    private static class Renderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean sel, boolean foc) {
            Item it = (Item) v;
            JLabel c = (JLabel) super.getListCellRendererComponent(l, "", i, sel, false);
            c.setText("<html><b>" + Ui.esc(it.title) + "</b><br><font color='" + Theme.hex(Theme.MUTED)
                    + "' size='2'>" + Ui.esc(it.detail) + "</font></html>");
            c.setFont(Theme.font(Font.PLAIN, 13));
            c.setBackground(sel ? Theme.SELECT : Theme.SURFACE);
            c.setForeground(Theme.INK);
            c.setBorder(new EmptyBorder(4, 12, 4, 12));
            return c;
        }
    }

    // ------------------------------------------------------------ ready-made fields

    private static List<Item> memberItems(LibraryService s, String q) {
        List<Item> out = new ArrayList<Item>();
        try {
            for (Member m : s.suggestMembers(q, 6)) {
                String flag = (m.getFineOwed() > 0 || m.getOverdueLoans() > 0) ? " \u00B7 has overdue/fines" : "";
                out.add(new Item(m.getCode(), m.getName(), m.getContact() + " \u00B7 " + m.getActiveLoans()
                        + " of " + Loan.MAX_LOANS + " books out" + flag));
            }
        } catch (LibraryException ignored) { }
        return out;
    }

    private static List<Item> bookItems(LibraryService s, String q) {
        List<Item> out = new ArrayList<Item>();
        try {
            for (Book b : s.suggestBooks(q, 6)) {
                out.add(new Item(b.getCode(), b.getTitle(), b.getAuthor() + " \u00B7 "
                        + (b.isAvailable() ? b.getAvailableCopies() + " available" : "none available")));
            }
        } catch (LibraryException ignored) { }
        return out;
    }

    public static SuggestField members(LibraryService s) {
        return new SuggestField(16, "Type the member's name", q -> memberItems(s, q));
    }

    public static SuggestField books(LibraryService s) {
        return new SuggestField(16, "Type the book title", q -> bookItems(s, q));
    }

    /** Book field for returns: once a member is chosen, only the books that member has out are suggested. */
    public static SuggestField openLoanBooks(LibraryService s, SuggestField memberField) {
        return new SuggestField(16, "Type the book title", q -> {
            String mc = memberField.idOrNull('M');
            if (mc == null) return bookItems(s, q);
            List<Item> out = new ArrayList<Item>();
            try {
                for (Loan l : s.loansForMember(LibraryService.parseId(mc, 'M'))) {
                    if (!l.isReturned() && Fuzzy.score(q, l.getBookTitle()) > 0) {
                        out.add(new Item(Book.code(l.getBookId()), l.getBookTitle(),
                                "Due " + l.getDueDate().format(SHORT)));
                    }
                }
            } catch (LibraryException ignored) { }
            return out;
        });
    }
}