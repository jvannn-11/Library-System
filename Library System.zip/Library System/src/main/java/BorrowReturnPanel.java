import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Borrow & Return: type a member name and a book title, no IDs needed. */
public class BorrowReturnPanel extends JPanel implements Refreshable {
    private static final DateTimeFormatter SHORT = DateTimeFormatter.ofPattern("MMM d");
    private static final DateTimeFormatter LONG = DateTimeFormatter.ofPattern("MMM d, yyyy");

    private final LibraryService service;
    private final SuggestField bMember, bBook, rMember, rBook;
    private final Theme.HintBox bMemberHint = new Theme.HintBox(), bBookHint = new Theme.HintBox();
    private final Theme.HintBox bDueHint = new Theme.HintBox(), rHint = new Theme.HintBox();
    private final DefaultTableModel model = Theme.model("Member", "Book", "Borrowed", "Due", "Status", "");
    private final JTable table = Theme.table(model);
    private List<Loan> loans = new ArrayList<Loan>();

    public BorrowReturnPanel(LibraryService service) {
        this.service = service;
        bMember = SuggestField.members(service);
        bBook = SuggestField.books(service);
        rMember = SuggestField.members(service);
        rBook = SuggestField.openLoanBooks(service, rMember);
        setLayout(new BorderLayout());
        setOpaque(false);

        JPanel page = Theme.page();
        page.add(Theme.pageHeader("Borrow & Return",
                        Theme.subtitle("Type a member's name and a book title. Suggestions appear as you type."), null),
                BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(0, 24));
        body.setOpaque(false);

        JPanel forms = new JPanel(new GridLayout(1, 2, 24, 0));
        forms.setOpaque(false);

        // ---- borrow card
        Theme.RoundedPanel borrow = Theme.card(18, 24);
        borrow.setLayout(new BoxLayout(borrow, BoxLayout.Y_AXIS));
        JButton borrowBtn = Theme.button("Confirm borrow");
        borrow.add(Theme.cardTitle("Borrow"));
        borrow.add(Box.createVerticalStrut(10));
        borrow.add(Theme.fill(Theme.formRow("Member name", bMember)));
        borrow.add(Box.createVerticalStrut(6));
        borrow.add(Theme.fill(bMemberHint));
        borrow.add(Box.createVerticalStrut(10));
        borrow.add(Theme.fill(Theme.formRow("Book title", bBook)));
        borrow.add(Box.createVerticalStrut(6));
        borrow.add(Theme.fill(bBookHint));
        borrow.add(Box.createVerticalStrut(10));
        borrow.add(Theme.fill(bDueHint));
        borrow.add(Box.createVerticalStrut(12));
        borrow.add(Theme.fill(borrowBtn));

        // ---- return card
        Theme.RoundedPanel ret = Theme.card(18, 24);
        ret.setLayout(new BoxLayout(ret, BoxLayout.Y_AXIS));
        JButton returnBtn = Theme.outlineButton("Confirm return");
        ret.add(Theme.cardTitle("Return"));
        ret.add(Box.createVerticalStrut(10));
        ret.add(Theme.fill(Theme.formRow("Borrower's name", rMember)));
        ret.add(Box.createVerticalStrut(10));
        ret.add(Theme.fill(Theme.formRow("Book title", rBook)));
        ret.add(Box.createVerticalStrut(10));
        ret.add(Theme.fill(rHint));
        ret.add(Box.createVerticalStrut(12));
        ret.add(Theme.fill(returnBtn));
        ret.add(Box.createVerticalGlue());

        forms.add(borrow);
        forms.add(ret);
        body.add(forms, BorderLayout.NORTH);

        Theme.setWidths(table, 200, 260, 100, 100, 140, 110);
        new Theme.ButtonColumn(table, 5, row -> returnRow(row));
        Theme.RoundedPanel tableCard = Theme.tableCard(table);
        JPanel tableWrap = new JPanel(new BorderLayout(0, 10));
        tableWrap.setOpaque(false);
        tableWrap.add(Theme.cardTitle("Active loans"), BorderLayout.NORTH);
        tableWrap.add(tableCard, BorderLayout.CENTER);
        body.add(tableWrap, BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        add(page);

        bMember.addChangeListener(this::updateBorrowHints);
        bBook.addChangeListener(this::updateBorrowHints);
        rMember.addChangeListener(this::updateReturnHint);
        rBook.addChangeListener(this::updateReturnHint);
        borrowBtn.addActionListener(e -> doBorrow());
        returnBtn.addActionListener(e -> doReturn());
        updateBorrowHints();
        updateReturnHint();
    }

    private void updateBorrowHints() {
        String m = bMember.idOrNull('M');
        if (bMember.getText().trim().isEmpty()) {
            bMemberHint.set("Start typing the member's name", Theme.NEUTRAL);
        } else if (m == null) {
            bMemberHint.set("No exact match yet. Keep typing or pick from the list.", Theme.NEUTRAL);
        } else {
            try {
                Member mem = service.findMember(m);
                if (mem == null) {
                    bMemberHint.set("No member found. Register them first.", Theme.ERR);
                } else if (mem.getFineOwed() > 0 || mem.getOverdueLoans() > 0) {
                    bMemberHint.set("<b>" + Ui.esc(mem.getName()) + "</b> \u00B7 has overdue books or fines", Theme.ERR);
                } else {
                    bMemberHint.set("<b>" + Ui.esc(mem.getName()) + "</b> \u00B7 " + mem.getActiveLoans() + " of "
                            + Loan.MAX_LOANS + " books out", Theme.OK);
                }
            } catch (LibraryException e) {
                bMemberHint.set(e.getMessage(), Theme.ERR);
            }
        }
        String b = bBook.idOrNull('B');
        if (bBook.getText().trim().isEmpty()) {
            bBookHint.set("Start typing the book title or author", Theme.NEUTRAL);
        } else if (b == null) {
            bBookHint.set("No exact match yet. Keep typing or pick from the list.", Theme.NEUTRAL);
        } else {
            try {
                Book book = service.findBook(b);
                if (book == null) bBookHint.set("No book found.", Theme.ERR);
                else if (!book.isAvailable()) bBookHint.set("<b>" + Ui.esc(book.getTitle()) + "</b> \u00B7 no copies available", Theme.ERR);
                else bBookHint.set("<b>" + Ui.esc(book.getTitle()) + "</b> \u00B7 " + book.getAvailableCopies()
                            + " of " + book.getTotalCopies() + " copies available", Theme.OK);
            } catch (LibraryException e) {
                bBookHint.set(e.getMessage(), Theme.ERR);
            }
        }
        bDueHint.set("Due date: <b>" + LocalDate.now().plusDays(Loan.LOAN_DAYS).format(LONG) + "</b> ("
                + Loan.LOAN_DAYS + " days) \u00B7 fine " + Theme.money(Loan.FINE_PER_DAY) + " per day late", Theme.NEUTRAL);
    }

    private void updateReturnHint() {
        if (rMember.getText().trim().isEmpty() || rBook.getText().trim().isEmpty()) {
            rHint.set("Type the borrower's name, then the book title.", Theme.NEUTRAL);
            return;
        }
        String m = rMember.idOrNull('M'), b = rBook.idOrNull('B');
        if (m == null || b == null) {
            rHint.set("No exact match yet. Keep typing or pick from the list.", Theme.NEUTRAL);
            return;
        }
        try {
            Loan l = service.findOpenLoan(m, b);
            if (l == null) {
                rHint.set("This member has not borrowed that book.", Theme.ERR);
            } else if (l.daysLate(LocalDate.now()) > 0) {
                rHint.set("<b>" + Ui.esc(l.getBookTitle()) + "</b> was due " + l.getDueDate().format(SHORT) + " \u00B7 "
                        + l.daysLate(LocalDate.now()) + " days late \u00B7 fine <b>"
                        + Theme.money(l.fine(LocalDate.now())) + "</b>", Theme.ERR);
            } else {
                rHint.set("<b>" + Ui.esc(l.getBookTitle()) + "</b> \u00B7 due " + l.getDueDate().format(SHORT)
                        + " \u00B7 returned on time", Theme.OK);
            }
        } catch (LibraryException e) {
            rHint.set(e.getMessage(), Theme.ERR);
        }
    }

    private void doBorrow() {
        String m = bMember.idOrNull('M'), b = bBook.idOrNull('B');
        if (m == null || b == null) {
            Theme.error(this, "Type the member's name and the book title, then pick them from the suggestions.");
            return;
        }
        try {
            Loan l = service.borrowBook(m, b);
            Theme.info(this, l.getMemberName() + " borrowed \"" + l.getBookTitle() + "\".\nDue on "
                    + l.getDueDate().format(LONG) + ".");
            bMember.setText("");
            bBook.setText("");
            refresh();
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
    }

    private void doReturn() {
        String m = rMember.idOrNull('M'), b = rBook.idOrNull('B');
        if (m == null || b == null) {
            Theme.error(this, "Type the borrower's name and the book title, then pick them from the suggestions.");
            return;
        }
        try {
            finishReturn(service.returnBook(m, b));
            rMember.setText("");
            rBook.setText("");
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
    }

    private void returnRow(int row) {
        if (row < 0 || row >= loans.size()) return;
        try {
            finishReturn(service.returnLoan(loans.get(row).getLoanId()));
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
    }

    private void finishReturn(Loan l) {
        LocalDate today = LocalDate.now();
        if (l.daysLate(today) > 0) {
            Theme.info(this, "\"" + l.getBookTitle() + "\" returned.\nIt was " + l.daysLate(today)
                    + " days late. Fine: " + Theme.money(l.fine(today))
                    + "\nCollect it in the Overdue & Fines screen.");
        } else {
            Theme.info(this, "\"" + l.getBookTitle() + "\" returned on time. Thank you!");
        }
        refresh();
    }

    @Override
    public void refresh() {
        try {
            loans = service.activeLoans();
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
            return;
        }
        LocalDate today = LocalDate.now();
        model.setRowCount(0);
        for (Loan l : loans) {
            long late = l.daysLate(today);
            Theme.Chip status = late > 0 ? new Theme.Chip(late + " days late", Theme.ERR)
                    : new Theme.Chip("On time", Theme.OK);
            model.addRow(new Object[] { l.getMemberName(), l.getBookTitle(), l.getBorrowDate().format(SHORT),
                    l.getDueDate().format(SHORT), status, "Return" });
        }
        updateBorrowHints();
        updateReturnHint();
    }
}