import javax.swing.*;
import java.awt.*;

/** Holds the pages. play() slides the new page up and reveals it from top to bottom. */
public class FadePanel extends JPanel {
    private static final int BAND = 140, STRIP = 8;
    private final Anim anim = new Anim(this, 750);

    public FadePanel(LayoutManager layout) {
        super(layout);
        setOpaque(false);
        anim.jump(1);
    }

    public void play() {
        anim.jump(0);
        anim.setTarget(1);
    }

    @Override
    protected void paintChildren(Graphics g) {
        float e = anim.eased();
        Graphics2D shifted = (Graphics2D) g.create();
        shifted.translate(0, Math.round((1f - e) * 16f));
        super.paintChildren(shifted);
        shifted.dispose();

        if (e < 0.995f) {
            int w = getWidth(), h = getHeight();
            float line = (h + BAND) * e - BAND;
            Graphics2D o = (Graphics2D) g.create();
            for (int y = (int) line; y < line + BAND; y += STRIP) {
                if (y + STRIP <= 0) continue;
                float a = Math.min(1f, Math.max(0f, (y + STRIP / 2f - line) / BAND));
                o.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
                Backdrop.draw(o, this, 0, y, w, STRIP);
            }
            int solid = Math.max(0, (int) (line + BAND));
            if (solid < h) {
                o.setComposite(AlphaComposite.SrcOver);
                Backdrop.draw(o, this, 0, solid, w, h - solid);
            }
            o.dispose();
        }
    }
}