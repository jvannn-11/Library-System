
/**
 * The member's window.
 * Everything shared with the admin window lives in Shell.
 */
public class MemberFrame extends Shell {

    public MemberFrame(LibraryService service, Account account, Runnable onLogout) {
        super("Member portal");

        // Get the member's name
        String name = account.getUsername();

        try {
            Member m = service.findMember(Member.code(account.getMemberId()));

            if (m != null) {
                name = m.getName();
            }

        } catch (LibraryException ignored) {
            // Use the account username if member details cannot be found
        }

        // Home screen
        addScreen(
                "home",
                "Home",
                Icons.HOME,
                new MemberHomePanel(service, account, this)
        );

        // Browse books screen
        addScreen(
                "browse",
                "Browse books",
                Icons.SEARCH,
                new MemberBrowsePanel(service, account)
        );

        // My books / loans screen
        addScreen(
                "loans",
                "My books",
                Icons.LIST,
                new MemberLoansPanel(service, account)
        );

        // Finish the shared window setup
        finish(name, "Member", onLogout);
    }
}
