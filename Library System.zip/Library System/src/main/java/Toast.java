import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** A small notification that slides in at the bottom-right of the window, then fades away. */
public final class Toast extends JComponent {
    private static Toast current;

    private final List<String> lines = new ArrayList<String>();
    private final Color accent;
    private final int boxW, boxH, lineH;
    private final JLayeredPane layer;
    private final long hold;
    private final long born = System.currentTimeMillis();
    private final javax.swing.Timer timer;
    private float alpha;
    private int slide = 24;

    private Toast(JLayeredPane layer, String message, int kind) {
        this.layer = layer;
        this.accent = kind == Theme.ERR ? new Color(0xEF4444) : new Color(0x10B981);
        this.hold = kind == Theme.ERR ? 4500 : 3200;
        Font font = Theme.font(Font.PLAIN, 14);
        setFont(font);
        FontMetrics fm = layer.getFontMetrics(font);
        int maxText = 340, widest = 0;
        for (String para : message.split("\n")) {
            String line = "";
            for (String word : para.split(" ")) {
                String test = line.isEmpty() ? word : line + " " + word;
                if (fm.stringWidth(test) > maxText && !line.isEmpty()) {
                    lines.add(line);
                    widest = Math.max(widest, fm.stringWidth(line));
                    line = word;
                } else {
                    line = test;
                }
            }
            lines.add(line);
            widest = Math.max(widest, fm.stringWidth(line));
        }
        lineH = fm.getHeight() + 2;
        boxW = widest + 56;
        boxH = lines.size() * lineH + 28;
        setSize(boxW + 8, boxH + 8);
        setOpaque(false);
        timer = new javax.swing.Timer(16, e -> tick());
    }

    /** kind is Theme.OK or Theme.ERR. Falls back to a normal dialog if there is no window yet. */
    public static void show(Component parent, String message, int kind) {
        Window w = parent instanceof Window ? (Window) parent
                : (parent == null ? null : SwingUtilities.getWindowAncestor(parent));
        if (!(w instanceof RootPaneContainer) || !w.isShowing()) {
            boolean err = kind == Theme.ERR;
            JOptionPane.showMessageDialog(parent, message, err ? "Cannot continue" : "Done",
                    err ? JOptionPane.WARNING_MESSAGE : JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JLayeredPane layer = ((RootPaneContainer) w).getLayeredPane();
        if (current != null) current.dismiss();
        Toast t = new Toast(layer, message == null ? "" : message, kind);
        current = t;
        layer.add(t, JLayeredPane.POPUP_LAYER);
        t.place();
        t.timer.start();
    }

    private void place() {
        setLocation(layer.getWidth() - getWidth() - 24, layer.getHeight() - getHeight() - 24 + slide);
    }

    private void tick() {
        long t = System.currentTimeMillis() - born;
        float in = Math.min(1f, t / 250f);
        float out = t > hold ? Math.min(1f, (t - hold) / 300f) : 0f;
        alpha = in * (1f - out);
        float eased = 1f - (1f - in) * (1f - in);
        slide = Math.round((1f - eased) * 24f);
        place();
        repaint();
        if (out >= 1f) dismiss();
    }

    private void dismiss() {
        timer.stop();
        Container p = getParent();
        if (p != null) {
            p.remove(this);
            p.repaint(getX(), getY(), getWidth(), getHeight());
        }
        if (current == this) current = null;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.max(0f, Math.min(1f, alpha))));
        for (int i = 1; i <= 4; i++) {
            g2.setColor(new Color(0, 0, 0, 14));
            g2.fillRoundRect(i, i + 1, boxW - 1, boxH - 1, 18, 18);
        }
        g2.setColor(Theme.SURFACE);
        g2.fillRoundRect(0, 0, boxW, boxH, 16, 16);
        g2.setColor(Theme.BORDER);
        g2.drawRoundRect(0, 0, boxW, boxH, 16, 16);
        g2.setColor(accent);
        g2.fillRoundRect(10, 12, 5, boxH - 24, 5, 5);
        g2.setFont(getFont());
        g2.setColor(Theme.INK);
        int y = 14 + g2.getFontMetrics().getAscent();
        for (String line : lines) {
            g2.drawString(line, 28, y);
            y += lineH;
        }
        g2.dispose();
    }
}