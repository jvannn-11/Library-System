import javax.swing.*;
import java.awt.*;
import java.time.format.DateTimeFormatter;

/** Member screen: browse the catalogue. Hover a book and press Borrow, or click it for details. */
public class MemberBrowsePanel extends JPanel implements Refreshable {
    private final LibraryService service;
    private final Account account;
    private final BookBrowser browser;

    public MemberBrowsePanel(LibraryService service, Account account) {
        this.service = service;
        this.account = account;
        browser = new BookBrowser(service,
                b -> BookDialog.show(this, service, b, account, this::refresh),
                this::quickBorrow);
        setLayout(new BorderLayout());
        setOpaque(false);
        JPanel page = Theme.page();
        page.add(Theme.pageHeader("Browse books",
                        Theme.subtitle("Hover a book and press Borrow, or click it to see its details."), null),
                BorderLayout.NORTH);
        page.add(browser, BorderLayout.CENTER);
        add(page);
    }

    private void quickBorrow(Book b) {
        if (!Theme.confirm(this, "Borrow \"" + b.getTitle() + "\"?\nIt will be due in " + Loan.LOAN_DAYS + " days.")) {
            return;
        }
        try {
            Loan l = service.borrowBook(Member.code(account.getMemberId()), b.getCode());
            Theme.info(this, "You borrowed \"" + l.getBookTitle() + "\". Due on "
                    + l.getDueDate().format(DateTimeFormatter.ofPattern("MMM d, yyyy")) + ".");
            refresh();
        } catch (LibraryException e) {
            Theme.error(this, e.getMessage());
        }
    }

    @Override
    public void refresh() { browser.refresh(); }
}