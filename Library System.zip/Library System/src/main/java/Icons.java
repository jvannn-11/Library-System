import java.awt.*;
import java.awt.geom.*;

/** Simple vector icons drawn in code (no image files). */
public final class Icons {
    private Icons() { }

    public static final int DASHBOARD = 0, BOOK = 1, USERS = 2, SWAP = 3, ALERT = 4, HOME = 5, SEARCH = 6,
            LIST = 7, LOGOUT = 8, SUN = 9, MOON = 10, CHEVRON_LEFT = 11, CHEVRON_RIGHT = 12, HEART = 13,
            CLOCK = 14, COIN = 15, PLUS = 16;

    /** Draws icon `kind` inside a size x size box at (x, y). */
    public static void paint(Graphics2D g0, int kind, double x, double y, double size, Color color, boolean filled) {
        if (kind < 0) return;
        Graphics2D g = (Graphics2D) g0.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.translate(x, y);
        double s = size / 24.0;
        g.scale(s, s);
        g.setColor(color);
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (kind) {
            case DASHBOARD:
                g.draw(new RoundRectangle2D.Double(3, 3, 7, 9, 2, 2));
                g.draw(new RoundRectangle2D.Double(14, 3, 7, 5, 2, 2));
                g.draw(new RoundRectangle2D.Double(14, 12, 7, 9, 2, 2));
                g.draw(new RoundRectangle2D.Double(3, 16, 7, 5, 2, 2));
                break;
            case BOOK: {
                Path2D.Double b = new Path2D.Double();
                b.moveTo(12, 6.5);
                b.curveTo(10, 4.8, 6.5, 4.2, 3, 4.8);
                b.lineTo(3, 18.8);
                b.curveTo(6.5, 18.2, 10, 18.8, 12, 20.5);
                b.curveTo(14, 18.8, 17.5, 18.2, 21, 18.8);
                b.lineTo(21, 4.8);
                b.curveTo(17.5, 4.2, 14, 4.8, 12, 6.5);
                b.closePath();
                g.draw(b);
                g.draw(new Line2D.Double(12, 6.5, 12, 20.5));
                break;
            }
            case USERS: {
                g.draw(new Ellipse2D.Double(5.5, 4, 7, 7));
                Path2D.Double a = new Path2D.Double();
                a.moveTo(2.5, 20);
                a.curveTo(2.5, 15.5, 5.5, 14.2, 9, 14.2);
                a.curveTo(12.5, 14.2, 15.5, 15.5, 15.5, 20);
                g.draw(a);
                g.draw(new Ellipse2D.Double(14.5, 5.5, 5.5, 5.5));
                Path2D.Double c = new Path2D.Double();
                c.moveTo(17.5, 14.4);
                c.curveTo(20, 14.6, 21.7, 16, 21.7, 19.5);
                g.draw(c);
                break;
            }
            case SWAP: {
                Path2D.Double a = new Path2D.Double();
                a.moveTo(4, 8); a.lineTo(20, 8);
                a.moveTo(16, 4); a.lineTo(20, 8); a.lineTo(16, 12);
                a.moveTo(20, 16); a.lineTo(4, 16);
                a.moveTo(8, 12); a.lineTo(4, 16); a.lineTo(8, 20);
                g.draw(a);
                break;
            }
            case ALERT: {
                Path2D.Double t = new Path2D.Double();
                t.moveTo(12, 3.5); t.lineTo(22, 20.5); t.lineTo(2, 20.5); t.closePath();
                g.draw(t);
                g.draw(new Line2D.Double(12, 9.5, 12, 14.2));
                g.fill(new Ellipse2D.Double(11, 16.3, 2, 2));
                break;
            }
            case HOME: {
                Path2D.Double h = new Path2D.Double();
                h.moveTo(3, 11); h.lineTo(12, 3.5); h.lineTo(21, 11); h.lineTo(21, 20.5);
                h.lineTo(15, 20.5); h.lineTo(15, 14.5); h.lineTo(9, 14.5); h.lineTo(9, 20.5);
                h.lineTo(3, 20.5); h.closePath();
                g.draw(h);
                break;
            }
            case SEARCH:
                g.draw(new Ellipse2D.Double(4.5, 4.5, 13, 13));
                g.draw(new Line2D.Double(16, 16, 21, 21));
                break;
            case LIST:
                for (int i = 0; i < 3; i++) {
                    double yy = 6 + i * 6;
                    g.draw(new Line2D.Double(8, yy, 21, yy));
                    g.fill(new Ellipse2D.Double(2.5, yy - 1, 2, 2));
                }
                break;
            case LOGOUT: {
                Path2D.Double d = new Path2D.Double();
                d.moveTo(10, 4); d.lineTo(5.5, 4);
                d.curveTo(4.6, 4, 4, 4.6, 4, 5.5);
                d.lineTo(4, 18.5);
                d.curveTo(4, 19.4, 4.6, 20, 5.5, 20);
                d.lineTo(10, 20);
                g.draw(d);
                Path2D.Double ar = new Path2D.Double();
                ar.moveTo(9, 12); ar.lineTo(20, 12);
                ar.moveTo(16.5, 8.5); ar.lineTo(20, 12); ar.lineTo(16.5, 15.5);
                g.draw(ar);
                break;
            }
            case SUN:
                g.draw(new Ellipse2D.Double(7.8, 7.8, 8.4, 8.4));
                for (int i = 0; i < 8; i++) {
                    double ang = i * Math.PI / 4;
                    g.draw(new Line2D.Double(12 + Math.cos(ang) * 7.2, 12 + Math.sin(ang) * 7.2,
                            12 + Math.cos(ang) * 10, 12 + Math.sin(ang) * 10));
                }
                break;
            case MOON: {
                Area moon = new Area(new Ellipse2D.Double(3.5, 3.5, 17, 17));
                moon.subtract(new Area(new Ellipse2D.Double(9, 0.5, 16, 16)));
                if (filled) g.fill(moon); else g.draw(moon);
                break;
            }
            case CHEVRON_LEFT: {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(15, 5); p.lineTo(8, 12); p.lineTo(15, 19);
                g.draw(p);
                break;
            }
            case CHEVRON_RIGHT: {
                Path2D.Double p = new Path2D.Double();
                p.moveTo(9, 5); p.lineTo(16, 12); p.lineTo(9, 19);
                g.draw(p);
                break;
            }
            case HEART: {
                Path2D.Double h = new Path2D.Double();
                h.moveTo(12, 20.5);
                h.curveTo(4, 14.5, 2.5, 10.5, 2.5, 7.8);
                h.curveTo(2.5, 5.2, 4.5, 3.5, 7, 3.5);
                h.curveTo(9, 3.5, 11, 4.5, 12, 6.5);
                h.curveTo(13, 4.5, 15, 3.5, 17, 3.5);
                h.curveTo(19.5, 3.5, 21.5, 5.2, 21.5, 7.8);
                h.curveTo(21.5, 10.5, 20, 14.5, 12, 20.5);
                h.closePath();
                if (filled) g.fill(h); else g.draw(h);
                break;
            }
            case CLOCK: {
                g.draw(new Ellipse2D.Double(3, 3, 18, 18));
                Path2D.Double hands = new Path2D.Double();
                hands.moveTo(12, 7); hands.lineTo(12, 12); hands.lineTo(15.5, 14);
                g.draw(hands);
                break;
            }
            case COIN: {
                g.draw(new Ellipse2D.Double(3, 3, 18, 18));
                Path2D.Double pp = new Path2D.Double();
                pp.moveTo(10.2, 17); pp.lineTo(10.2, 7.2); pp.lineTo(13.2, 7.2);
                pp.curveTo(15.6, 7.2, 15.6, 12, 13.2, 12);
                pp.lineTo(10.2, 12);
                g.draw(pp);
                g.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.draw(new Line2D.Double(8.2, 9.1, 15.3, 9.1));
                g.draw(new Line2D.Double(8.2, 10.7, 15.3, 10.7));
                break;
            }
            case PLUS:
                g.draw(new Line2D.Double(12, 5, 12, 19));
                g.draw(new Line2D.Double(5, 12, 19, 12));
                break;
            default:
                break;
        }
        g.dispose();
    }
}