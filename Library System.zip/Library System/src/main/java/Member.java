/** A registered library member, with their current loan standing. */
public class Member {
    private final int memberId;
    private final String name;
    private final String address;
    private final String contact;
    private final int activeLoans;
    private final int overdueLoans;
    private final double fineOwed;

    public Member(int memberId, String name, String address, String contact,
                  int activeLoans, int overdueLoans, double fineOwed) {
        this.memberId = memberId;
        this.name = name;
        this.address = address;
        this.contact = contact;
        this.activeLoans = activeLoans;
        this.overdueLoans = overdueLoans;
        this.fineOwed = fineOwed;
    }

    public static String code(int id) { return String.format("M%03d", id); }

    public int getMemberId()     { return memberId; }
    public String getCode()      { return code(memberId); }
    public String getName()      { return name; }
    public String getAddress()   { return address; }
    public String getContact()   { return contact; }
    public int getActiveLoans()  { return activeLoans; }
    public int getOverdueLoans() { return overdueLoans; }
    public double getFineOwed()  { return fineOwed; }

    public boolean matches(String keyword) {
        String k = keyword.toLowerCase();
        return getCode().toLowerCase().contains(k) || name.toLowerCase().contains(k)
            || contact.toLowerCase().contains(k);
    }

    @Override
    public String toString() { return getCode() + " " + name; }
}
