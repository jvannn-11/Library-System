import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.function.Consumer;

/** A book tile: cover, title, author, availability. Lifts and zooms on hover; can show a quick Borrow button. */
public class BookCard extends JPanel {
    private final Book book;
    private final int w, coverH;
    private final Consumer<Book> onClick, onBorrow;
    private final Anim hover = new Anim(this, 200);
    private final Rectangle borrowRect = new Rectangle();
    private boolean overBorrow;
    private String badge;

    public BookCard(Book book, int w, int coverH, Consumer<Book> onClick) {
        this(book, w, coverH, onClick, null);
    }

    public BookCard(Book book, int w, int coverH, Consumer<Book> onClick, Consumer<Book> onBorrow) {
        this.book = book;
        this.w = w;
        this.coverH = coverH;
        this.onClick = onClick;
        this.onBorrow = onBorrow;
        setOpaque(false);
        setPreferredSize(new Dimension(w, coverH + 90));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setToolTipText(book.getTitle() + " - " + book.getAuthor());
        MouseAdapter m = new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { hover.setTarget(1); }
            public void mouseExited(MouseEvent e) { hover.setTarget(0); setOver(false); }
            public void mouseMoved(MouseEvent e) { setOver(borrowRect.contains(e.getPoint())); }
            public void mouseReleased(MouseEvent e) {
                if (!contains(e.getPoint())) return;
                if (BookCard.this.onBorrow != null && borrowRect.contains(e.getPoint())) {
                    BookCard.this.onBorrow.accept(BookCard.this.book);
                } else if (BookCard.this.onClick != null) {
                    BookCard.this.onClick.accept(BookCard.this.book);
                }
            }
        };
        addMouseListener(m);
        addMouseMotionListener(m);
    }

    public void setBadge(String text) { badge = text; repaint(); }

    private void setOver(boolean o) {
        if (o != overBorrow) {
            overBorrow = o;
            repaint();
        }
    }

    private static String fit(String s, FontMetrics fm, int max) {
        if (fm.stringWidth(s) <= max) return s;
        while (s.length() > 1 && fm.stringWidth(s + "\u2026") > max) s = s.substring(0, s.length() - 1);
        return s + "\u2026";
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        float e = hover.eased();
        int y = Math.round(4 * (1f - e));
        int cw = w - 1, ch = coverH + 84;

        if (e > 0.01f) {
            g2.setColor(new Color(15, 60, 52, Math.round(28 * e)));
            g2.fillRoundRect(3, y + 6, cw - 4, ch, 16, 16);
            g2.setColor(new Color(15, 60, 52, Math.round(16 * e)));
            g2.fillRoundRect(1, y + 3, cw - 2, ch, 16, 16);
        }
        g2.setColor(Theme.SURFACE);
        g2.fillRoundRect(0, y, cw, ch, 16, 16);

        Shape old = g2.getClip();
        g2.clip(new RoundRectangle2D.Float(0, y, cw, ch, 16, 16));
        g2.clip(new Rectangle(0, y, w, coverH));
        float z = 1f + 0.06f * e;
        int dw = Math.round(w * z), dh = Math.round(coverH * z);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(Covers.load(book, w, coverH), (w - dw) / 2, y + (coverH - dh) / 2, dw, dh, null);
        g2.setClip(old);

        g2.setColor(Theme.mix(Theme.BORDER, Theme.ACCENT, e));
        g2.drawRoundRect(0, y, cw, ch, 16, 16);

        int tx = 12, tw = w - 24;
        g2.setFont(Theme.font(Font.BOLD, 14));
        g2.setColor(Theme.INK);
        g2.drawString(fit(book.getTitle(), g2.getFontMetrics(), tw), tx, y + coverH + 24);
        g2.setFont(Theme.font(Font.PLAIN, 12));
        g2.setColor(Theme.MUTED);
        g2.drawString(fit(book.getAuthor(), g2.getFontMetrics(), tw), tx, y + coverH + 42);

        int kind = book.isAvailable() ? Theme.OK : Theme.WARN;
        String st = book.isAvailable() ? book.getAvailableCopies() + " available" : "All on loan";
        g2.setFont(Theme.font(Font.BOLD, 11));
        FontMetrics fm = g2.getFontMetrics();
        g2.setColor(Theme.bg(kind));
        g2.fillRoundRect(tx, y + coverH + 52, fm.stringWidth(st) + 20, 22, 22, 22);
        g2.setColor(Theme.fg(kind));
        g2.drawString(st, tx + 10, y + coverH + 67);

        if (badge != null) {
            g2.setFont(Theme.font(Font.BOLD, 11));
            fm = g2.getFontMetrics();
            g2.setColor(new Color(0, 0, 0, 165));
            g2.fillRoundRect(8, y + 8, fm.stringWidth(badge) + 16, 22, 22, 22);
            g2.setColor(Color.WHITE);
            g2.drawString(badge, 16, y + 23);
        }

        borrowRect.setBounds(0, 0, 0, 0);
        if (onBorrow != null && book.isAvailable() && e > 0.05f) {
            int bw = w - 24, bh = 34, bx = 12;
            int by = y + coverH - 12 - bh + Math.round((1f - e) * 24f);
            Graphics2D b = (Graphics2D) g2.create();
            b.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.min(1f, e)));
            b.setColor(Theme.mix(Theme.PRIMARY, Theme.PRIMARY_DARK, overBorrow ? 1f : 0f));
            b.fillRoundRect(bx, by, bw, bh, 12, 12);
            b.setColor(Color.WHITE);
            b.setFont(Theme.font(Font.BOLD, 13));
            FontMetrics bf = b.getFontMetrics();
            String label = "Borrow";
            b.drawString(label, bx + (bw - bf.stringWidth(label)) / 2, by + (bh - bf.getHeight()) / 2 + bf.getAscent());
            b.dispose();
            if (e > 0.7f) borrowRect.setBounds(bx, by, bw, bh);
        }
        g2.dispose();
    }
}