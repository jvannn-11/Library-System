
/**
 * The admin window.
 * Uses Shell for the shared sidebar, top bar,
 * navigation, and screen transitions.
 */
public class MainFrame extends Shell {

    public MainFrame(LibraryService service, Runnable onLogout) {

        super("Public Library");

        // Dashboard
        addScreen(
                "dashboard",
                "Dashboard",
                Icons.DASHBOARD,
                new DashboardPanel(service, this)
        );

        // Book catalog
        addScreen(
                "catalog",
                "Catalog",
                Icons.BOOK,
                new CatalogPanel(service)
        );

        // Library members
        addScreen(
                "members",
                "Members",
                Icons.USERS,
                new MembersPanel(service)
        );

        // Borrowing and returning
        addScreen(
                "borrow",
                "Borrow & Return",
                Icons.SWAP,
                new BorrowReturnPanel(service)
        );

        // Overdue books and fines
        addScreen(
                "overdue",
                "Overdue & Fines",
                Icons.ALERT,
                new OverduePanel(service)
        );

        // Finish building the admin window
        finish(
                "Librarian",
                "Administrator",
                onLogout
        );
    }
}
