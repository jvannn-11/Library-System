import javax.swing.*;
import java.util.prefs.Preferences;

/** Start here: run main in IntelliJ. */
public class App {
    private static final Preferences PREFS = Preferences.userRoot().node("thelibrary");
    private static LibraryService service;
    private static Account account;
    private static Shell frame;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(App::start);
    }

    static void start() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) { }
        try {
            Database.initialize();
            service = new LibraryService();
            service.loadSampleDataIfEmpty();
            service.ensureSampleLogins();

            Theme.setDark(false);          // the sign-in window is always light
            Modern.install();
            Account a = LoginDialog.prompt(service);
            if (a == null) {
                System.exit(0);
            }
            account = a;

            Theme.setDark(PREFS.getBoolean("dark", false));
            Modern.install();
            open(account.isAdmin() ? "dashboard" : "home");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "The library system could not start:\n" + e.getMessage(), "Startup error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    /** Opens the window for the signed-in account on the given page. */
    private static void open(String screen) {
        Shell f = account.isAdmin()
                ? new MainFrame(service, App::start)                 // "Log out" calls start() again
                : new MemberFrame(service, account, App::start);
        frame = f;
        f.setVisible(true);
        f.show(screen);
    }

    /** Switches between light and dark mode by rebuilding the window on the same page. */
    static void toggleTheme(String screen) {
        boolean dark = !Theme.isDark();
        PREFS.putBoolean("dark", dark);
        Theme.setDark(dark);
        Modern.install();
        Shell old = frame;
        open(screen == null ? (account.isAdmin() ? "dashboard" : "home") : screen);
        if (old != null) old.dispose();
    }
}