import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** One member borrowing one book. Holds the dates and works out lateness and fines. */
public class Loan {
    public static final int LOAN_DAYS = 14;
    public static final double FINE_PER_DAY = 5.00;   // pesos
    public static final int MAX_LOANS = 3;

    private final int loanId;
    private final int bookId;
    private final String bookTitle;
    private final int memberId;
    private final String memberName;
    private final LocalDate borrowDate;
    private final LocalDate dueDate;
    private final LocalDate returnDate;   // null while the book is still out
    private final double fineAmount;      // fixed when the book is returned
    private final boolean finePaid;

    public Loan(int loanId, int bookId, String bookTitle, int memberId, String memberName,
                LocalDate borrowDate, LocalDate dueDate, LocalDate returnDate,
                double fineAmount, boolean finePaid) {
        this.loanId = loanId;
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.memberId = memberId;
        this.memberName = memberName;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.fineAmount = fineAmount;
        this.finePaid = finePaid;
    }

    public int getLoanId()           { return loanId; }
    public int getBookId()           { return bookId; }
    public String getBookTitle()     { return bookTitle; }
    public int getMemberId()         { return memberId; }
    public String getMemberName()    { return memberName; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public LocalDate getDueDate()    { return dueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public boolean isFinePaid()      { return finePaid; }
    public boolean isReturned()      { return returnDate != null; }

    /** Days late. For a returned book this is measured at the return date. */
    public long daysLate(LocalDate today) {
        LocalDate end = isReturned() ? returnDate : today;
        return Math.max(0, ChronoUnit.DAYS.between(dueDate, end));
    }

    /** Fine owed: the stored fine if returned, otherwise the fine building up today. */
    public double fine(LocalDate today) {
        return isReturned() ? fineAmount : daysLate(today) * FINE_PER_DAY;
    }
}
