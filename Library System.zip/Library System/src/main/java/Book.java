/** A title in the catalogue. Fields are private (encapsulation); data is read through getters. */
public class Book {
    private final int bookId;
    private final String title;
    private final String author;
    private final String category;
    private final int totalCopies;
    private final int availableCopies;
    private final String imagePath;   // file name inside ~/LibrarySystem/covers, or ""

    public Book(int bookId, String title, String author, String category,
                int totalCopies, int availableCopies, String imagePath) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.category = category;
        this.totalCopies = totalCopies;
        this.availableCopies = availableCopies;
        this.imagePath = imagePath == null ? "" : imagePath;
    }

    public Book(int bookId, String title, String author, String category,
                int totalCopies, int availableCopies) {
        this(bookId, title, author, category, totalCopies, availableCopies, "");
    }

    public static String code(int id) { return String.format("B%03d", id); }

    public int getBookId()          { return bookId; }
    public String getCode()         { return code(bookId); }
    public String getTitle()        { return title; }
    public String getAuthor()       { return author; }
    public String getCategory()     { return category; }
    public int getTotalCopies()     { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }
    public String getImagePath()    { return imagePath; }
    public boolean isAvailable()    { return availableCopies > 0; }

    /** Case-insensitive match on code, title, author or category. */
    public boolean matches(String keyword) {
        String k = keyword.toLowerCase();
        return getCode().toLowerCase().contains(k) || title.toLowerCase().contains(k)
                || author.toLowerCase().contains(k) || category.toLowerCase().contains(k);
    }

    @Override
    public String toString() { return getCode() + " " + title; }
}