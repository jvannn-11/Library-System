import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Glass top bar: live clock, light/dark toggle, avatar and name. */
public class TopBar extends JPanel {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("EEEE, MMM d  \u00B7  h:mm a");
    private final JLabel clock = Theme.label(" ", 13, Font.PLAIN, Theme.MUTED);
    private final javax.swing.Timer ticker = new javax.swing.Timer(1000, e -> tick());

    public TopBar(String name, String role, Runnable onToggleTheme) {
        setOpaque(false);
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(10, 36, 10, 36));
        add(clock, BorderLayout.WEST);

        JPanel text = Theme.column();
        JLabel n = Theme.label(name, 13, Font.BOLD, Theme.INK);
        JLabel r = Theme.label(role, 11, Font.PLAIN, Theme.MUTED);
        n.setAlignmentX(Component.RIGHT_ALIGNMENT);
        r.setAlignmentX(Component.RIGHT_ALIGNMENT);
        text.add(n);
        text.add(r);
        JPanel who = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        who.setOpaque(false);
        who.add(new ThemeToggle(onToggleTheme));
        who.add(text);
        who.add(new Avatar(name));
        add(who, BorderLayout.EAST);
        tick();
    }

    private void tick() { clock.setText(LocalDateTime.now().format(FMT)); }

    @Override public void addNotify() { super.addNotify(); ticker.start(); }
    @Override public void removeNotify() { ticker.stop(); super.removeNotify(); }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(Theme.isDark() ? new Color(13, 21, 20, 150) : new Color(255, 255, 255, 150));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setColor(Theme.BORDER);
        g2.fillRect(0, getHeight() - 1, getWidth(), 1);
        g2.dispose();
    }

    /** Round button that switches between light and dark mode. */
    private static class ThemeToggle extends JComponent {
        private final Anim hover = new Anim(this, 160);

        ThemeToggle(Runnable action) {
            setPreferredSize(new Dimension(38, 38));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setToolTipText(Theme.isDark() ? "Switch to light mode" : "Switch to dark mode");
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hover.setTarget(1); }
                public void mouseExited(MouseEvent e) { hover.setTarget(0); }
                public void mouseReleased(MouseEvent e) {
                    if (contains(e.getPoint())) action.run();
                }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            float t = hover.eased();
            g2.setColor(Theme.mix(Theme.SURFACE, Theme.SELECT, t));
            g2.fillOval(0, 0, 37, 37);
            g2.setColor(Theme.mix(Theme.BORDER, Theme.ACCENT, t));
            g2.drawOval(0, 0, 37, 37);
            boolean dark = Theme.isDark();
            Icons.paint(g2, dark ? Icons.SUN : Icons.MOON, 9, 9, 20,
                    dark ? new Color(0xFCD34D) : new Color(0x6D28D9), false);
            g2.dispose();
        }
    }

    private static class Avatar extends JComponent {
        private final String initial;

        Avatar(String name) {
            initial = name == null || name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
            setPreferredSize(new Dimension(38, 38));
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setPaint(new GradientPaint(0, 0, Theme.PRIMARY_DARK, 38, 38, new Color(0x14B8A6)));
            g2.fillOval(0, 0, 37, 37);
            g2.setColor(Color.WHITE);
            g2.setFont(Theme.font(Font.BOLD, 16));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(initial, (38 - fm.stringWidth(initial)) / 2, (38 - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }
}