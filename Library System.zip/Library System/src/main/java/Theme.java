import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Area;
import java.awt.geom.RoundRectangle2D;
import java.util.function.IntConsumer;

/** Colours (light and dark), fonts and ready-made styled components, so every screen looks the same. */
public final class Theme {
    private Theme() { }

    private static boolean dark;
    public static boolean isDark() { return dark; }

    // these change with the light/dark mode
    public static Color INK, MUTED, BG, BORDER, ROW_LINE, FIELD_BORDER, FIELD_BG, SURFACE, INSET, SELECT, HOVER_ROW;
    public static Color GLASS, GLASS_EDGE, GLASS_SHINE, ACCENT;
    public static Color OK_BG, OK_FG, WARN_BG, WARN_FG, ERR_BG, ERR_FG;

    // these stay the same in both modes
    public static final Color SIDEBAR = new Color(0x12302A);
    public static final Color SIDE_ACTIVE = new Color(0x1F4A41);
    public static final Color SIDE_TEXT = new Color(0xE7F0ED);
    public static final Color SIDE_MUTED = new Color(0xA9C4BD);
    public static final Color PRIMARY = new Color(0x0F766E);
    public static final Color PRIMARY_DARK = new Color(0x0B5F58);

    public static final int NEUTRAL = 0, OK = 1, WARN = 2, ERR = 3;

    static { setDark(false); }

    /** Switch the colours. Windows must be rebuilt afterwards (App.toggleTheme does that). */
    public static void setDark(boolean d) {
        dark = d;
        if (d) {
            INK = new Color(0xE8F1EF);        MUTED = new Color(0x9DB2AD);      BG = new Color(0x0D1514);
            BORDER = new Color(0x2A3B3F);     ROW_LINE = new Color(0x223034);   FIELD_BORDER = new Color(0x3A4F54);
            FIELD_BG = new Color(0x16232A);   SURFACE = new Color(0x131E22);    INSET = new Color(0x0F1A1D);
            SELECT = new Color(0x1E3B3A);     HOVER_ROW = new Color(0x1A2A2E);
            GLASS = new Color(26, 40, 44, 188);
            GLASS_EDGE = new Color(0x2F4348); GLASS_SHINE = new Color(255, 255, 255, 20);
            ACCENT = new Color(0x2DD4BF);
            OK_BG = new Color(0x123D2B);      OK_FG = new Color(0x6EE7B7);
            WARN_BG = new Color(0x4A3512);    WARN_FG = new Color(0xFCD34D);
            ERR_BG = new Color(0x4A1D22);     ERR_FG = new Color(0xFCA5A5);
        } else {
            INK = new Color(0x1F2937);        MUTED = new Color(0x4B5563);      BG = new Color(0xF3F7F6);
            BORDER = new Color(0xDCE6E3);     ROW_LINE = new Color(0xEAF0EE);   FIELD_BORDER = new Color(0xCBD5D1);
            FIELD_BG = Color.WHITE;           SURFACE = Color.WHITE;            INSET = new Color(0xF1F5F4);
            SELECT = new Color(0xEAF4F2);     HOVER_ROW = new Color(0xF4F9F8);
            GLASS = new Color(255, 255, 255, 190);
            GLASS_EDGE = new Color(0xD5E3E0); GLASS_SHINE = new Color(255, 255, 255, 170);
            ACCENT = new Color(0x0F766E);
            OK_BG = new Color(0xDCFCE7);      OK_FG = new Color(0x166534);
            WARN_BG = new Color(0xFEF3C7);    WARN_FG = new Color(0x92400E);
            ERR_BG = new Color(0xFEE2E2);     ERR_FG = new Color(0x991B1B);
        }
    }

    private static final String FAMILY = pickFamily();

    private static String pickFamily() {
        java.util.Set<String> have = new java.util.HashSet<String>(java.util.Arrays.asList(
                GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        for (String f : new String[] { "Inter", "SF Pro Text", "Segoe UI", "Helvetica Neue", "Arial" }) {
            if (have.contains(f)) return f;
        }
        return "SansSerif";
    }

    public static Font font(int style, int size) { return new Font(FAMILY, style, size); }

    static Color fg(int kind) {
        switch (kind) { case OK: return OK_FG; case WARN: return WARN_FG; case ERR: return ERR_FG; default: return MUTED; }
    }
    static Color bg(int kind) {
        switch (kind) { case OK: return OK_BG; case WARN: return WARN_BG; case ERR: return ERR_BG; default: return ROW_LINE; }
    }

    /** Blend two colours: t = 0 gives a, t = 1 gives b. (Result is opaque.) */
    static Color mix(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(Math.round(a.getRed() + (b.getRed() - a.getRed()) * t),
                Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }

    /** "#RRGGBB" for use inside HTML text. */
    public static String hex(Color c) {
        return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
    }

    public static String money(double v) { return "\u20B1" + String.format("%,.2f", v); }

    /** Outline on a text box while it has focus. Call after the border is set. */
    public static void focusRing(final JTextComponent f) {
        final Border normal = f.getBorder();
        final Border focus = BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT, 2), new EmptyBorder(8, 11, 8, 11));
        f.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { f.setBorder(focus); }
            @Override public void focusLost(FocusEvent e) { f.setBorder(normal); }
        });
    }

    // ------------------------------------------------------------ panels

    /**
     * A panel with rounded corners. A white fill means "glass": translucent, so the colourful
     * background shows through. Can have a soft shadow and a hover glow.
     */
    public static class RoundedPanel extends JPanel {
        private Color fill;
        private final Color line;
        private final int arc;
        private final boolean glass;
        private boolean shadow;
        private Anim hover;

        public RoundedPanel(Color fill, Color line, int arc) {
            this.fill = fill;
            this.line = line;
            this.arc = arc;
            this.glass = Color.WHITE.equals(fill);
            setOpaque(false);
        }

        public RoundedPanel withShadow() { shadow = true; return this; }

        /** Shadow that deepens and an accent border while the mouse is over the card. */
        public RoundedPanel withHover() {
            shadow = true;
            hover = new Anim(this, 200);
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hover.setTarget(1); }
                public void mouseExited(MouseEvent e) { hover.setTarget(0); }
            });
            return this;
        }

        public void setFill(Color c) { fill = c; repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            float e = hover == null ? 0f : hover.eased();
            int w = shadow ? getWidth() - 5 : getWidth() - 1;
            int h = shadow ? getHeight() - 6 : getHeight() - 1;
            if (shadow) {
                Area outside = new Area(new Rectangle(0, 0, getWidth(), getHeight()));
                outside.subtract(new Area(new RoundRectangle2D.Float(0, 0, w, h, arc, arc)));
                Shape old = g2.getClip();
                g2.clip(outside);
                int a = Math.round((dark ? 34 : 9) + 10 * e);
                for (int i = 1; i <= 4; i++) {
                    g2.setColor(dark ? new Color(0, 0, 0, a) : new Color(16, 48, 42, a));
                    g2.fillRoundRect(i - 1, i + 1, w, h, arc + 2, arc + 2);
                }
                g2.setClip(old);
            }
            g2.setColor(glass ? GLASS : fill);
            g2.fillRoundRect(0, 0, w, h, arc, arc);
            if (glass) {
                g2.setPaint(new GradientPaint(0, 0, GLASS_SHINE, 0, Math.max(40, Math.min(h, 90)),
                        new Color(255, 255, 255, 0)));
                g2.fillRoundRect(0, 0, w, h, arc, arc);
                g2.setColor(mix(GLASS_EDGE, ACCENT, 0.55f * e));
                g2.drawRoundRect(0, 0, w, h, arc, arc);
            } else if (line != null) {
                g2.setColor(mix(line, ACCENT, 0.5f * e));
                g2.drawRoundRect(0, 0, w, h, arc, arc);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static RoundedPanel card(int vPad, int hPad) {
        RoundedPanel p = new RoundedPanel(Color.WHITE, BORDER, 14).withShadow();
        p.setBorder(new EmptyBorder(vPad, hPad, vPad, hPad));
        return p;
    }

    /** Small message box (grey, green, amber or red). */
    public static class HintBox extends RoundedPanel {
        private final JLabel text = new JLabel(" ");
        private int wrap = 0;

        public HintBox() {
            super(INSET, null, 10);
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(10, 12, 10, 12));
            text.setFont(font(Font.PLAIN, 13));
            add(text);
            set("", NEUTRAL);
        }

        /** For long messages: wrap the text at this many pixels. */
        public HintBox wrap(int px) { wrap = px; return this; }

        public void set(String html, int kind) {
            setFill(kind == NEUTRAL ? INSET : bg(kind));
            text.setForeground(kind == NEUTRAL ? MUTED : fg(kind));
            String body = html.isEmpty() ? "&nbsp;" : html;
            text.setText(wrap > 0 ? "<html><body style='width:" + wrap + "px'>" + body + "</body></html>"
                    : "<html>" + body + "</html>");
        }
    }

    /** Vertical panel with no background. */
    public static JPanel column() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        return p;
    }

    /** Left-align and stretch a component inside a column(). */
    public static <T extends JComponent> T fill(T c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, c.getPreferredSize().height));
        return c;
    }

    /** A page: transparent, so the gradient backdrop shows through. */
    public static JPanel page() {
        JPanel p = new JPanel(new BorderLayout(0, 24));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(32, 36, 32, 36));
        return p;
    }

    public static JPanel pageHeader(String title, JLabel subtitle, Component right) {
        JPanel h = new JPanel(new BorderLayout());
        h.setOpaque(false);
        JPanel left = column();
        JLabel t = label(title, 26, Font.BOLD, INK);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        left.add(t);
        left.add(Box.createVerticalStrut(4));
        left.add(subtitle);
        h.add(left, BorderLayout.WEST);
        if (right != null) h.add(right, BorderLayout.EAST);
        return h;
    }

    public static JLabel label(String text, int size, int style, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(style, size));
        l.setForeground(color);
        return l;
    }

    public static JLabel subtitle(String text) { return label(text, 14, Font.PLAIN, MUTED); }

    /** A big number label. When it is set to a whole number it counts up to it. */
    public static class CountLabel extends JLabel {
        private int shown;
        private boolean ready;
        private javax.swing.Timer timer;

        public CountLabel(Color color) {
            super("0");
            setFont(font(Font.BOLD, 30));
            setForeground(color);
            ready = true;
        }

        @Override
        public void setText(String text) {
            if (timer != null) timer.stop();
            Integer to = text != null && text.matches("\\d{1,7}") ? Integer.valueOf(text) : null;
            if (!ready || to == null || to == shown) {
                super.setText(text);
                if (to != null) shown = to;
                return;
            }
            final int from = shown;
            final int target = to;
            final long start = System.currentTimeMillis();
            timer = new javax.swing.Timer(16, e -> {
                float p = Math.min(1f, (System.currentTimeMillis() - start) / 500f);
                float eased = 1f - (1f - p) * (1f - p) * (1f - p);
                shown = from + Math.round((target - from) * eased);
                super.setText(String.valueOf(shown));
                if (p >= 1f) timer.stop();
            });
            timer.start();
        }
    }

    public static JLabel big(Color color) { return new CountLabel(color); }

    private static int iconFor(String title) {
        String t = title.toLowerCase();
        if (t.contains("fine")) return Icons.COIN;
        if (t.contains("overdue") && !t.contains("longest")) return Icons.ALERT;
        if (t.contains("longest") || t.contains("due within")) return Icons.CLOCK;
        if (t.contains("member")) return Icons.USERS;
        if (t.contains("loan") || t.contains("out")) return Icons.SWAP;
        if (t.contains("title")) return Icons.BOOK;
        return Icons.DASHBOARD;
    }

    private static Color tint(int icon) {
        switch (icon) {
            case Icons.BOOK:  return new Color(0x0F9D8F);
            case Icons.USERS: return new Color(0x3B82F6);
            case Icons.SWAP:  return new Color(0xF59E0B);
            case Icons.ALERT: return new Color(0xEF4444);
            case Icons.CLOCK: return new Color(0x8B5CF6);
            case Icons.COIN:  return new Color(0xEC4899);
            default:          return PRIMARY;
        }
    }

    /** Coloured rounded square with an icon, shown on stat cards. */
    private static class IconBadge extends JComponent {
        private final int icon;

        IconBadge(int icon) {
            this.icon = icon;
            setPreferredSize(new Dimension(46, 46));
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color c = tint(icon);
            g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), dark ? 60 : 40));
            g2.fillRoundRect(0, 0, 45, 45, 16, 16);
            Icons.paint(g2, icon, 11, 11, 24, dark ? mix(c, Color.WHITE, 0.35f) : c, false);
            g2.dispose();
        }
    }

    public static RoundedPanel statCard(String title, JLabel value) {
        RoundedPanel p = card(16, 20).withHover();
        p.setLayout(new BorderLayout(12, 0));
        JPanel text = column();
        JLabel t = label(title, 13, Font.PLAIN, MUTED);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        value.setAlignmentX(Component.LEFT_ALIGNMENT);
        text.add(t);
        text.add(Box.createVerticalStrut(4));
        text.add(value);
        p.add(text, BorderLayout.CENTER);
        JPanel right = new JPanel(new GridBagLayout());
        right.setOpaque(false);
        right.add(new IconBadge(iconFor(title)));
        p.add(right, BorderLayout.EAST);
        return p;
    }

    public static JLabel cardTitle(String text) {
        JLabel l = label(text, 16, Font.BOLD, INK);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    // ------------------------------------------------------------ inputs and buttons

    public static JTextField field(int columns) {
        JTextField f = new JTextField(columns);
        f.setFont(font(Font.PLAIN, 14));
        f.setForeground(INK);
        f.setBackground(FIELD_BG);
        f.setCaretColor(INK);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(FIELD_BORDER), new EmptyBorder(9, 12, 9, 12)));
        focusRing(f);
        return f;
    }

    /** A search box that shows grey hint text while it is empty. */
    public static JTextField searchField(int columns, String placeholder) {
        JTextField f = new JTextField(columns) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    g2.setColor(MUTED);
                    g2.setFont(getFont());
                    g2.drawString(placeholder, getInsets().left, (getHeight() + g2.getFontMetrics().getAscent()
                            - g2.getFontMetrics().getDescent()) / 2);
                    g2.dispose();
                }
            }
        };
        f.setFont(font(Font.PLAIN, 14));
        f.setForeground(INK);
        f.setBackground(FIELD_BG);
        f.setCaretColor(INK);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(FIELD_BORDER), new EmptyBorder(9, 12, 9, 12)));
        focusRing(f);
        return f;
    }

    /** A small label above an input. */
    public static JPanel formRow(String label, JComponent input) {
        JPanel p = column();
        JLabel l = label(label, 13, Font.BOLD, INK);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        input.setAlignmentX(Component.LEFT_ALIGNMENT);
        input.setMaximumSize(new Dimension(Integer.MAX_VALUE, input.getPreferredSize().height));
        p.add(l);
        p.add(Box.createVerticalStrut(6));
        p.add(input);
        return p;
    }

    public static class RoundedButton extends JButton {
        private final boolean outline;
        private final Anim hover = new Anim(this, 160);

        public RoundedButton(String text, boolean outline, int vPad, int hPad) {
            super(text);
            this.outline = outline;
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setFont(font(Font.BOLD, 13));
            setForeground(outline ? ACCENT : Color.WHITE);
            setBorder(new EmptyBorder(vPad, hPad, vPad, hPad));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hover.setTarget(1); }
                public void mouseExited(MouseEvent e) { hover.setTarget(0); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            float t = hover.eased();
            boolean on = isEnabled();
            int off = getModel().isPressed() ? 1 : 0;
            int w = getWidth() - 1, h = getHeight() - 3;
            if (!outline && on && t > 0.01f) {
                g2.setColor(new Color(15, 118, 110, Math.round(55 * t)));
                g2.fillRoundRect(2, 3, w - 3, h, 12, 12);
            }
            if (!on) {
                g2.setColor(mix(SURFACE, MUTED, 0.3f));
                g2.fillRoundRect(0, off, w, h, 12, 12);
            } else if (outline) {
                g2.setColor(mix(SURFACE, SELECT, t));
                g2.fillRoundRect(0, off, w, h, 12, 12);
                g2.setColor(ACCENT);
                g2.drawRoundRect(0, off, w, h, 12, 12);
            } else {
                g2.setPaint(new GradientPaint(0, 0, mix(PRIMARY, PRIMARY_DARK, t),
                        Math.max(1, w), 0, mix(new Color(0x14A39A), PRIMARY, t)));
                g2.fillRoundRect(0, off, w, h, 12, 12);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static JButton button(String text)        { return new RoundedButton(text, false, 12, 22); }
    public static JButton outlineButton(String text) { return new RoundedButton(text, true, 12, 22); }
    public static JButton smallButton(String text)   { return new RoundedButton(text, true, 6, 14); }

    /** Run something whenever the text in a field changes. */
    public static void onChange(JTextComponent f, Runnable r) {
        f.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { r.run(); }
            public void removeUpdate(DocumentEvent e) { r.run(); }
            public void changedUpdate(DocumentEvent e) { r.run(); }
        });
    }

    // ------------------------------------------------------------ messages

    public static void error(Component parent, String msg) { Toast.show(parent, msg, ERR); }
    public static void info(Component parent, String msg) { Toast.show(parent, msg, OK); }
    public static boolean confirm(Component parent, String msg) {
        return JOptionPane.showConfirmDialog(parent, msg, "Please confirm",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.OK_OPTION;
    }

    // ------------------------------------------------------------ tables

    /** A coloured pill shown inside a table cell, e.g. "Available" or "6 days late". */
    public static class Chip {
        final String text;
        final int kind;
        public Chip(String text, int kind) { this.text = text; this.kind = kind; }
        @Override public String toString() { return text; }
    }

    /** Read-only table model. A column whose header is "" holds a button, so only that column is editable. */
    public static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return getColumnName(c).isEmpty(); }
        };
    }

    private static class ChipLabel extends JLabel {
        private Color back = ROW_LINE;
        ChipLabel() {
            setFont(font(Font.BOLD, 12));
            setBorder(new EmptyBorder(4, 12, 4, 12));
            setOpaque(false);
        }
        void setChip(Chip c) { setText(c.text); setForeground(fg(c.kind)); back = bg(c.kind); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(back);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static boolean isHot(JTable t, int row) {
        Object hr = t.getClientProperty("hoverRow");
        return hr != null && hr.equals(Integer.valueOf(row));
    }

    private static class CellRenderer extends DefaultTableCellRenderer {
        private final ChipLabel chip = new ChipLabel();
        private final JPanel holder = new JPanel(new GridBagLayout());

        CellRenderer() {
            holder.setOpaque(true);
            holder.add(chip, new GridBagConstraints());
        }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            Color rowBg = sel ? SELECT : (isHot(t, r) ? HOVER_ROW : SURFACE);
            int left = c == 0 ? 20 : 8;
            if (v instanceof Chip) {
                chip.setChip((Chip) v);
                holder.setBackground(rowBg);
                holder.setBorder(BorderFactory.createCompoundBorder(
                        new MatteBorder(0, 0, 1, 0, ROW_LINE), new EmptyBorder(0, left, 0, 8)));
                ((GridBagLayout) holder.getLayout()).setConstraints(chip, anchorWest());
                return holder;
            }
            Object shown = v instanceof String ? ((String) v).replace("#4B5563", hex(MUTED)) : v;
            super.getTableCellRendererComponent(t, shown, false, false, r, c);
            setBackground(rowBg);
            setForeground(INK);
            setBorder(BorderFactory.createCompoundBorder(
                    new MatteBorder(0, 0, 1, 0, ROW_LINE), new EmptyBorder(0, left, 0, 8)));
            return this;
        }

        private GridBagConstraints anchorWest() {
            GridBagConstraints gc = new GridBagConstraints();
            gc.weightx = 1;
            gc.anchor = GridBagConstraints.WEST;
            return gc;
        }
    }

    private static class HeaderRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            super.getTableCellRendererComponent(t, v == null ? "" : v.toString().toUpperCase(), false, false, r, c);
            setFont(font(Font.BOLD, 11));
            setForeground(MUTED);
            setBackground(SURFACE);
            setOpaque(true);
            setBorder(BorderFactory.createCompoundBorder(
                    new MatteBorder(0, 0, 1, 0, BORDER), new EmptyBorder(0, c == 0 ? 20 : 8, 0, 8)));
            return this;
        }
    }

    private static void hoverRow(JTable t, int row) {
        Object old = t.getClientProperty("hoverRow");
        Integer now = row < 0 ? null : Integer.valueOf(row);
        if ((old == null && now == null) || (old != null && old.equals(now))) return;
        t.putClientProperty("hoverRow", now);
        t.repaint();
    }

    public static JTable table(DefaultTableModel m) {
        final JTable t = new JTable(m);
        t.setRowHeight(56);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setFont(font(Font.PLAIN, 14));
        t.setForeground(INK);
        t.setBackground(SURFACE);
        t.setSelectionBackground(SELECT);
        t.setSelectionForeground(INK);
        t.setFillsViewportHeight(true);
        t.getTableHeader().setReorderingAllowed(false);
        t.getTableHeader().setDefaultRenderer(new HeaderRenderer());
        t.getTableHeader().setPreferredSize(new Dimension(0, 44));
        t.setDefaultRenderer(Object.class, new CellRenderer());
        t.addMouseMotionListener(new MouseMotionAdapter() {
            @Override public void mouseMoved(MouseEvent e) { hoverRow(t, t.rowAtPoint(e.getPoint())); }
        });
        t.addMouseListener(new MouseAdapter() {
            @Override public void mouseExited(MouseEvent e) { hoverRow(t, -1); }
        });
        return t;
    }

    /** Wraps a table in a rounded card with a scroll bar. */
    public static RoundedPanel tableCard(JTable t) {
        RoundedPanel card = new RoundedPanel(Color.WHITE, BORDER, 14).withShadow();
        card.setLayout(new BorderLayout());
        card.setBorder(new EmptyBorder(1, 1, 7, 6));
        JScrollPane sp = new JScrollPane(t);
        sp.setBorder(null);
        sp.getViewport().setBackground(SURFACE);
        card.add(sp);
        return card;
    }

    public static void setWidths(JTable t, int... widths) {
        for (int i = 0; i < widths.length; i++) {
            t.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }

    /** Puts a clickable button in every row of one column. The cell text is the button label ("" = no button). */
    public static class ButtonColumn extends AbstractCellEditor implements TableCellRenderer, TableCellEditor {
        private final JPanel renderPanel = holder();
        private final JPanel editPanel = holder();
        private final JButton renderBtn = smallButton("");
        private final JButton editBtn = smallButton("");
        private int editRow;

        public ButtonColumn(JTable table, int column, IntConsumer action) {
            renderPanel.add(renderBtn);
            editPanel.add(editBtn);
            editBtn.addActionListener(e -> {
                int row = editRow;
                fireEditingStopped();
                action.accept(row);
            });
            table.getColumnModel().getColumn(column).setCellRenderer(this);
            table.getColumnModel().getColumn(column).setCellEditor(this);
        }

        private static JPanel holder() {
            JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
            p.setOpaque(true);
            p.setBackground(SURFACE);
            p.setBorder(new MatteBorder(0, 0, 1, 0, ROW_LINE));
            return p;
        }

        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            String text = v == null ? "" : v.toString();
            renderBtn.setText(text);
            renderBtn.setVisible(!text.isEmpty());
            renderPanel.setBackground(isHot(t, r) ? HOVER_ROW : SURFACE);
            return renderPanel;
        }

        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) {
            String text = v == null ? "" : v.toString();
            editRow = r;
            editBtn.setText(text);
            editBtn.setVisible(!text.isEmpty());
            editPanel.setBackground(HOVER_ROW);
            return editPanel;
        }

        public Object getCellEditorValue() { return editBtn.getText(); }
    }
}